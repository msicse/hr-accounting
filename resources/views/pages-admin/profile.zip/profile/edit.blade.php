@extends('layout.admin')
@section('title','Admin | Profile Edit')
@section('contentBody')
    <div class="card">
        <div class="card-header">
            <h2>Profile Create</h2>
        </div>
        <div class="card-body card-padding">
            <form role="form" method="POST" action="{{url('profile',$profile_edit->id)}}" class="remove-margin-p" enctype="multipart/form-data" >
                <input type="hidden" name="_method" value="PUT">
                <input type="hidden" name="_token" value="{{ csrf_token() }}">
                    <div class="form-group ">
                        <div class="fg-line">
                            <label for="full_name">Employee Id</label>
                            <input type="text" class="form-control input-sm" id="employee_id" name="employee_id" placeholder="Enter employee_id"
                            @if( empty( Input::old('employee_id')))
                                               value = " {{ $profile_edit->employee_id }} "
                                            @else
                                                 value="{{ Input::old('employee_id')  }}"
                                            @endif

                            />
                        </div>
                        @if ($errors->has('employee_id'))
                            <p class="text-right text-danger">{{$errors->first('employee_id')}}</p>
                        @endif
                    </div>
                    <div class="form-group ">
                        <div class="fg-line">
                            <label for="full_name">Full Name</label>
                            <input type="text" class="form-control input-sm" id="full_name" name="full_name" placeholder="Enter full_name"
                            @if( empty( Input::old('full_name')))
                                               value = " {{ $profile_edit->full_name }} "
                                            @else
                                                 value="{{ Input::old('full_name')  }}"
                                            @endif

                            />
                        </div>
                        @if ($errors->has('full_name'))
                            <p class="text-right text-danger">{{$errors->first('full_name')}}</p>
                        @endif
                    </div>
                    <div class="form-group ">
                        <div class="fg-line">
                            <label for="father_name">Father Name</label>
                            <input type="text" class="form-control input-sm" id="father_name" name="father_name" placeholder="father_name" 
                            @if( empty( Input::old('father_name')))
                                               value = " {{ $profile_edit->father_name }} "
                                            @else
                                                 value="{{ Input::old('father_name')  }}"
                                            @endif
                            
                            />
                        </div>
                        @if ($errors->has('father_name'))
                         <p class="text-right text-danger">{{$errors->first('father_name')}}</p>
                        @endif
                    </div>
                    <div class="form-group ">
                        <div class="fg-line">
                            <label for="mother_name">Mother Name</label>
                            <input type="text" class="form-control input-sm" id="mother_name" name="mother_name" placeholder="mother name"
                            @if( empty( Input::old('mother_name')))
                                               value = " {{ $profile_edit->mother_name }} "
                                            @else
                                                 value="{{ Input::old('mother_name')  }}"
                                            @endif
                            />
                        </div>
                        @if ($errors->has('mother_name'))
                         <p class="text-right text-danger">{{$errors->first('mother_name')}}</p>
                        @endif
                    </div>
                    <div class="form-group ">
                        <div class="fg-line">
                            <label for="nid">National ID</label>
                            <input type="text" class="form-control input-sm" id="nid" name="nid" placeholder="nid"
                            @if( empty( Input::old('nid')))
                                               value = " {{ $profile_edit->nid }} "
                                            @else
                                                 value="{{ Input::old('nid')  }}"
                                            @endif
                             />
                        </div>
                        @if ($errors->has('nid'))
                         <p class="text-right text-danger">{{$errors->first('nid')}}</p>
                        @endif
                    </div>
                    <div class="form-group ">
                        <div class="fg-line">
                            <label class="radio radio-inline m-r-20">
                                <input type="radio" name="gender" value="1" />
                                <i class="input-helper"></i>Male
                            </label>
                            <label class="radio radio-inline m-r-20">
                                <input type="radio" name="gender" value="2"/>
                                <i class="input-helper"></i>Female
                            </label>
                        </div>
                        <hr>
                        @if ($errors->has('gender'))
                            <p class="text-right text-danger">{{$errors->first('gender')}}</p>
                        @endif
                    </div>
                    <div class="form-group ">
                        <div class="fg-line">
                            <label class="radio radio-inline m-r-20">
                                <input type="radio" name="maritial_status" value="1">
                                <i class="input-helper"></i>Married
                            </label>
                            <label class="radio radio-inline m-r-20">
                                <input type="radio" name="maritial_status" value="2">
                                <i class="input-helper"></i>Unmarried
                            </label>
                        </div>
                        <hr>
                        @if ($errors->has('maritial_status'))
                            <p class="text-right text-danger">{{$errors->first('maritial_status')}}</p>
                        @endif
                    </div>
                    <div class="col-sm-4">
                        <h4>Date of Birth</h4>
                            <div class="input-group form-group">
                                <span class="input-group-addon"><i class="zmdi zmdi-calendar"></i></span>
                                    <div class="dtp-container">
                                        <input type='text' class="form-control date-picker" placeholder="Click here..." id="date_of_birth" name="date_of_birth"/>
                                    </div>
                            </div>
                        </div>
                    <div class="col-sm-4">
                        <div class="form-group">
                            <div class="fg-line">
                                <div class="select">
                                    <h4>Religion</h4>
                                    <select class="form-control" name="religion">
                                        <option></option>
                                        <option value="1">Islam</option>
                                        <option value="2">Hinduism</option>
                                        <option value="3">Buddhism</option>
                                        <option value="4">Christianity</option>
                                  </select>
                            
                                </div>
                            </div>
                    
                                @if ($errors->has('religion'))
                                 <p class="text-right text-danger">{{$errors->first('religion')}}</p>
                                @endif
                        </div>
                    </div>
                    <div class="col-sm-4">
                        <div class="form-group">
                            <div class="fg-line">
                                <div class="select">
                                    <h4>Blood Group</h4>
                                    <select class="form-control" name="blood_group">
                                        <option></option>
                                        <option value="1">A+</option>
                                        <option value="2">A-</option>
                                        <option value="3">B+</option>
                                        <option value="4">B-</option>
                                        <option value="5">AB+</option>
                                        <option value="6">AB-</option>
                                        <option value="7">O+</option>
                                        <option value="8">O-</option>
                                  </select>
                            
                                </div>
                            </div>
                            @if ($errors->has('blood_group'))
                             <p class="text-right text-danger">{{$errors->first('blood_group')}}</p>
                            @endif
                        </div>
                    </div> 
                    <div class="form-group ">
                        <div class="fg-line">
                            <label for="phone">Phone</label>
                            <input type="text" class="form-control input-sm" id="phone" name="phone" placeholder="phone...."
                            @if( empty( Input::old('phone')))
                                               value = " {{ $profile_edit->phone }} "
                                            @else
                                                 value="{{ Input::old('phone')  }}"
                                            @endif
                            >
                        </div>
                        @if ($errors->has('phone'))
                         <p class="text-right text-danger">{{$errors->first('phone')}}</p>
                        @endif
                    </div>
                    <div class="form-group ">
                        <div class="fg-line">
                            <label for="email">Email</label>
                            <input type="text" class="form-control input-sm" id="email" name="email" placeholder="email...."
                            @if( empty( Input::old('email')))
                                               value = " {{ $profile_edit->email }} "
                                            @else
                                                 value="{{ Input::old('email')  }}"
                                            @endif
                            >
                        </div>
                        @if ($errors->has('email'))
                         <p class="text-right text-danger">{{$errors->first('email')}}</p>
                        @endif
                    </div>
                    <div class="form-group ">
                        <div class="fg-line">
                            <label for="fb">Facebook Url</label>
                            <input type="text" class="form-control input-sm" id="fb" name="fb" placeholder="ex.www.facebook.com/yourname"
                            @if( empty( Input::old('fb')))
                                               value = " {{ $profile_edit->fb }} "
                                            @else
                                                 value="{{ Input::old('fb')  }}"
                                            @endif
                            >
                        </div>
                        @if ($errors->has('fb'))
                         <p class="text-right text-danger">{{$errors->first('fb')}}</p>
                        @endif
                    </div>
                    <div class="form-group ">
                        <div class="fg-line">
                            <label for="fb">Skype</label>
                            <input type="text" class="form-control input-sm" id="skype" name="skype" placeholder="skype"
                            @if( empty( Input::old('skype')))
                                               value = " {{ $profile_edit->skype }} "
                                            @else
                                                 value="{{ Input::old('skype')  }}"
                                            @endif
                            >
                        </div>
                        @if ($errors->has('skype'))
                         <p class="text-right text-danger">{{$errors->first('skype')}}</p>
                        @endif
                    </div> 
                    <div class="form-group ">
                        <div class="fg-line">
                            <label for="marks">Marks</label>
                            <textarea class="form-control" rows="5" placeholder="marks......" name="marks" id="marks">@if( empty( Input::old('marks'))) {{ $profile_edit->marks }}@else
                                                 {{ Input::old('marks')  }}@endif</textarea>
                        </div>
                        @if ($errors->has('marks'))
                         <p class="text-right text-danger">{{$errors->first('marks')}}</p>
                        @endif
                    </div>
                    <div class="form-group ">
                        <div class="fg-line">
                            <label for="present_address">Present Address</label>
                            <textarea class="form-control" rows="5" placeholder="present address......" name="present_address" id="present_address">@if( empty( Input::old('present_address'))){{ $profile_edit->present_address }} 
                                            @else
                                                {{ Input::old('present_address')  }}
                                            @endif</textarea>
                        </div>
                        @if ($errors->has('present_address'))
                         <p class="text-right text-danger">{{$errors->first('present_address')}}</p>
                        @endif
                    </div> 
                    <div class="form-group ">
                        <div class="fg-line">
                            <label for="permanent_address">Permanant Address</label>
                            <textarea class="form-control" rows="5" placeholder="permanant address......" name="permanent_address" id="permanent_address">@if( empty( Input::old('permanent_address'))){{ $profile_edit->permanent_address }}
                                            @else
                                                {{ Input::old('permanent_address')  }}
                                            @endif
                            </textarea>
                        </div>
                        @if ($errors->has('permanent_address'))
                         <p class="text-right text-danger">{{$errors->first('permanent_address')}}</p>
                        @endif
                    </div>
                    <div class="form-group ">
                        <div class="fg-line">
                            <label for="emergency_contact_number">Emegency Contact No :</label>
                            <input type="text" class="form-control input-sm" id="emergency_contact_number" name="emergency_contact_number" placeholder="emergency contact no"
                            @if( empty( Input::old('emergency_contact_number')))
                                               value = " {{ $profile_edit->emergency_contact_number }} "
                                            @else
                                                 value="{{ Input::old('emergency_contact_number')  }}"
                                            @endif
                            >
                        </div>
                        @if ($errors->has('emergency_contact_number'))
                         <p class="text-right text-danger">{{$errors->first('emergency_contact_number')}}</p>
                        @endif
                    </div> 
                    <div class="form-group ">
                        <div class="fg-line">
                            <label for="emergency_address">Emergency Address </label>
                            <textarea class="form-control" rows="5" placeholder="emergency address......" name="emergency_address" id="emergency_address">@if(empty( Input::old('emergency_address'))){{ $profile_edit->emergency_address }}@else{{ Input::old('emergency_address')}}@endif</textarea>
                        </div>
                        @if ($errors->has('emergency_address'))
                         <p class="text-right text-danger">{{$errors->first('emergency_address')}}</p>
                        @endif
                    </div>
                    <div class="row">
                        <div class="col-sm-4">
                                <h4 class="c-black f-500 ">Date of Join</h4>
                                <div class="input-group form-group">
                                    <span class="input-group-addon"><i class="zmdi zmdi-calendar"></i></span>
                                        <div class="dtp-container">
                                            <input type='text' class="form-control date-picker" placeholder="Click here..." name="date_of_join"
                            @if( empty( Input::old('date_of_join')))
                                               value = " {{ $profile_edit->date_of_join }} "
                                            @else
                                                 value="{{ Input::old('date_of_join')  }}"
                                            @endif
                            >
                                        </div>
                                    @if ($errors->has('date_of_join'))
                                     <p class="text-right text-danger">{{$errors->first('date_of_join')}}</p>
                                    @endif
                                </div>
                        </div> 
                        <div class="col-sm-4 ">
                        <div class="form-group">
                            <div class="fg-line">
                                <div class="select">
                                    <h4>Designation</h4>
                                    <select class="form-control" name="designation_id">
                                        <option></option>
                                        @foreach( $designation as $data)
                                        <option value="{{ $data->id }}">{{$data->designation_name }}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                        </div>
                            @if ($errors->has('designation_id'))
                             <p class="text-right text-danger">{{$errors->first('designation_id')}}</p>
                            @endif
                        </div>
                        <div class="col-sm-4">
                            <div class="form-group">
                                <div class="fg-line">
                                    <div class="select">
                                        <h4>Shift</h4>
                                        <select class="form-control" name="shift">
                                            <option></option>
                                            <option value="1">Day</option>
                                            <option value="0">Night</option>
                                        </select>
                                
                                    </div>
                                </div>
                                @if ($errors->has('shift'))
                                 <p class="text-right text-danger">{{$errors->first('shift')}}</p>
                                @endif
                            </div>  
                        </div>
                    </div>
                    <div class="form-group ">
                        <div class="fg-line">
                            <label for="reference">Previous Employee Record </label>
                            <textarea class="form-control" rows="5" placeholder="permanant address......" name="previous_record" id="previous_record"></textarea>
                        </div>
                        @if ($errors->has('previous_record'))
                         <p class="text-right text-danger">{{$errors->first('previous_record')}}</p>
                        @endif
                    </div>
                    <div class="form-group ">
                        <div class="fg-line">
                            <label for="reference">Referenc </label>
                            <textarea class="form-control" rows="5" placeholder="permanant address......" name="reference" id="reference"></textarea>
                        </div>
                        @if ($errors->has('reference'))
                         <p class="text-right text-danger">{{$errors->first('reference')}}</p>
                        @endif
                    </div>
                    <div class="row">
                        <div class="col-sm-6 text-center m-b-30">
                            <h3 class="f-500 c-black m-b-20">Upload Profile </h3>
                           
                        <div class="fileinput fileinput-new" data-provides="fileinput">
                                <div class="fileinput-preview thumbnail" data-trigger="fileinput"></div>
                                <div>
                                    <span class="btn btn-info btn-file">
                                        <span class="fileinput-new">Select image</span>
                                        <span class="fileinput-exists">Change</span>
                                        <input type="file" name="profile_pic" >
                                    </span>
                                    <a href="#" class="btn btn-danger fileinput-exists"
                                       data-dismiss="fileinput">Remove</a>
                                </div>
                        </div>
                         @if ($errors->has('profile_pic'))
                         <p class="text-right text-danger">{{$errors->first('profile_pic')}}</p>
                        @endif
                        </div>
                        <div class="col-sm-6 text-center m-b-30">
                            <h3 class="f-500 c-black m-b-20">Upload NID </h3>
                           
                        <div class="fileinput fileinput-new" data-provides="fileinput">
                                <div class="fileinput-preview thumbnail" data-trigger="fileinput"></div>
                                <div>
                                    <span class="btn btn-info btn-file">
                                        <span class="fileinput-new">Select image</span>
                                        <span class="fileinput-exists">Change</span>
                                        <input type="file" name="nid_upload" >
                                    </span>
                                    <a href="#" class="btn btn-danger fileinput-exists"
                                       data-dismiss="fileinput">Remove</a>
                                </div>
                        </div>
                         @if ($errors->has('nid_upload'))
                         <p class="text-right text-danger">{{$errors->first('nid_upload')}}</p>
                        @endif
                        </div>
                    </div>
                <div class="row">
                    <div class="col-sm-12"> 
                    <center style="margin-top:20px; ">
                        <button type="submit" class="btn btn-primary btn-lg">Submit</button>
                    </center>
                        
                    </div>
                </div>
                
            </form>
        </div>
    </div>

@endsection