@extends('layout.admin')
@section('contentBody')
    
@if (Session::has('message'))
        <div class="alert alert-success">{{ Session::get('message') }}</div>
    @endif
    <div class="card">
        <div class="card-header">
            <h2>Employee Table</h2>
        </div>
        <div class="card-body table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>First Name</th>
                        <th>Designation</th>
                        <th>Employee Id</th>
                        <th>Phone</th>
                        <th>Profile Pic</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                <?php $i = 0 ; ?>
                @foreach( $profiles as $profile )
                    <?php $i++?>
                    <tr>
                        <td>{{ $i }}</td>
                        <td>{{ $profile->full_name }}</td>
                        <td>{{ $profile->designation_name }}</td>
                        <td>{{ $profile->employee_id }}</td>
                        <td>{{ $profile->phone }}</td>
                        <td> 
                        <img class="img-responsive" height="200" width="100" src="{{ url('uploads/profile_pic', $profile->profile_pic ) }}" alt="">

                        </td>

                        <td> 
                            <a href="{{ url('profile',$profile->id) }}">
                                <i class="fa fa-eye custom-font" aria-hidden="true"></i>
                            </a> 

                            <a href="{{ url('profile', [$profile->id,'edit']) }}" class=""><i class="fa fa-pencil custom-font" aria-hidden="true"></i></a>
                            
                            <a href="{{ url('profile',$profile->id) }}" data-method="delete" 
                            data-token="{{ csrf_token() }}" data-confirm="Are you sure?"><i class="fa fa-trash-o text-danger custom-font" aria-hidden="true"></i></a>

                        </td>
                        
                    </tr>
                @endforeach
                </tbody>
            </table>
        </div>
    </div>
@endsection