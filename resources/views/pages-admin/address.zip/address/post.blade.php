<select class="Bagerhat Sadar"   >
	<option value="">select</option>
	<option value="Bagerhat Sadar-9300">Bagerhat Sadar-9300</option>
	<option value="P.C College-9301">P.C College-9301</option>
	<option value="Rangdia-9302">Rangdia-9302</option>  
</select>

<select class="Bagerhat Chalna-Ankorage"   >
	<option value="">select</option>
	<option value="Chalna Ankorage-9350">Chalna Ankorage-9350</option>
	<option value="Mongla Port-9351">Mongla Port-9351</option>
</select>
<select class="Bagerhat Chitalmari"  >
	<option value="">select</option>
	<option value="Chalna Ankorage-9350">Chitalmari-9360</option>
	<option value="Mongla Port-9351">Barabaria-9361</option>
</select>
<select class="Bagerhat Fakirhat"  >
	<option value="">select</option>
	<option value="Bhanganpar Bazar-9372">Bhanganpar Bazar-9372</option>
	<option value="Fakirhat-9370">Fakirhat-9370</option>
	<option value="Mansa-9371">Mansa-9371</option>
</select>
<select class="Bagerhat Kachua-UPO"  >
	<option value="">select</option>
	<option value="Sonarkola-9311">Sonarkola-9311</option>
	<option value="Kachua-9310">Kachua-9310</option>

</select>
<select class="Bagerhat Mollahat"  >
	<option value="">select</option>
	<option value="Pak Gangni-9385">Pak Gangni-9385</option>
	<option value="Nagarkandi-9384">Nagarkandi-9384</option>
	<option value="Mollahat-9380">Mollahat-9380</option>
	<option value="Kahalpur-9381">Kahalpur-9381</option>
	<option value="Dariala-9382">Dariala-9382</option>
	<option value="Charkulia-9383">Charkulia-9383</option>

</select>
<select class="Bagerhat Morelganj"  >
	<option value="">select</option>
	<option value="Morelganj-9320">Morelganj-9320</option>
	<option value="Sannasi Bazar-9321">Sannasi Bazar-9321</option>
	<option value="Telisatee-9322">Telisatee-9322</option>

</select>

<select class="Bagerhat Rampal" >
	<option value="">select</option>
	<option value="Sonatunia-9342">Sonatunia-9342</option>
	<option value="Rampal-9340">Rampal-9340</option>
	<option value="Gourambha-9343">Gourambha-9343</option>
	<option value="Foylahat-9341">Foylahat-9341</option>

</select>
<select class="Bagerhat Rayenda">
	<option value="">select</option>
	<option value="Rayenda-9330">Rayenda-9330</option>
</select>

<select class="Chuadanga Sadar">
	<option value="Chuadanga Sadar-7200">Chuadanga Sadar-7200</option>
	<option value="Munshiganj-7201">Munshiganj-7201</option>
</select>

<select class="Chuadanga Alamdanga">
	<option value="Hardi-7211">Hardi-7211</option>
	<option value="Alamdanga-07210">Alamdanga-07210</option>
</select>

<select class="Chuadanga Damurhuda">
	<option value="Damurhuda-7220">Damurhuda-7220</option>
	<option value="Andulbaria-7222">Andulbaria-7222</option>
	<option value="Darshana-7221">Darshana-7221</option>
</select>

<select class="Chuadanga Doulatganj" >
	<option value="Doulatganj-7230">Doulatganj-7230</option>
</select>

<!--Jessore-->				
<select class="Jessore Sadar">
	<option value="" selected>Select a Post</option>
	<option value="Sadar-7400">Sadar-7400</option>
	<option value="Rupdia-7405">Rupdia-7405</option>
	<option value="Upa-Shahar-7401">Upa-Shahar-7401</option>
	<option value="Canttonment-7403">Canttonment-7403</option>
	<option value="Airbach-7404">Jessore Airbach-7404</option>
	<option value="Churamankathi-7407">Churamankathi-7407</option>
	<option value="Chanchra-7402">Chanchra-7402</option>
	<option value="Basundia-7406">Basundia-7406</option>
</select>

<select class="Jessore Chaugachha">

	<option value="Chougachha-7410"> Chougachha-7410 </option>

</select>

<select class="Jessore Bagharpara">
	<option value="" selected>Select a Post</option>
	<option value="Bagharpara-7470"> Bagharpara-7470 </option>
	<option value="Gouranagar-7471"> Gouranagar-7471 </option>

</select>

<select class="Jessore Sarsa" >
	<option value="" selected>Select a Post</option>
	<option value="Sarsa-7430"> Sarsa-7430 </option>
	<option value="Jadabpur-7432"> Jadabpur-7432 </option>
	<option value="Benapole-7431"> Benapole-7431 </option>
	<option value="Bag Achra-7433"> Bag Achra-7433 </option>

</select>

<select class="Jessore Noapara">
	<option value="" selected>Select a Post</option>
	<option value="Noapara-7460"> Noapara-7460 </option>
	<option value="Rajghat-7461"> Rajghat-7461 </option>
	<option value="Bhugilhat-7462"> Bhugilhat-7462 </option>


</select>

<select class="Jessore Monirampur">

	<option value="Monirampur-7440" selected> Monirampur-7440 </option>

</select>

<select class="Jessore Keshobpur"  >

	<option value="Keshobpur-7450" selected> Keshobpur-7450 </option>

</select>
<select class="Jessore Jhikargachha"  >

	<option value="Jhikargachha-7420" selected> Jhikargachha-7420 </option>

</select>

<!--Jinaidaha-->

<select class="Jinaidaha Shailakupa"  >

	<option value="" selected >Select a Post</option>
	<option value="Shailakupa-7320">Shailakupa-7320</option>
	<option value="Kumiradaha-7321">Kumiradaha-7321</option>

</select>

<select class="Jinaidaha Naldanga"  >

	<option value="" selected >Select a Post</option>
	<option value="Shailakupa-7320">Naldanga-7350</option>
	<option value="Hatbar Bazar-7351">Hatbar Bazar-7351</option>

</select>

<select class="Jinaidaha Maheshpur"  >

	<option value="Maheshpur-7340" selected >Maheshpur-7340</option>

</select>					

<select class="Jinaidaha Kotchandpur"  >

	<option value="Kotchandpur-7330" selected >Kotchandpur-7330</option>

</select>

<select class="Jinaidaha Sadar"  >

	<option value="" selected >Select a Post</option>
	<option value="Sadar-7300"  >Sadar-7300</option>
	<option value="Cadet-College-7301"  >Cadet-College-7301</option>

</select>

<select class="Jinaidaha Harinakundu"  >

	<option value="Harinakundu-7310" selected >Harinakundu-7310</option>

</select>

<!--Khulna-->
<select class="Khulna Terakhada"  >

	<option value="" selected >Select a Post </option>
	<option value="Terakhada-9230" >Terakhada-9230</option>
	<option value="Pak Barasat-9231" >Pak Barasat-9231</option>

</select>

<select class="Khulna Shahapur"  >

	<option value="" selected >Select a Post </option>
	<option value="Shahapur-9253" >Shahapur-9253</option>
	<option value="Sajiara-9250" >Sajiara-9250</option>
	<option value="Ghonabanda-9251" >Ghonabanda-9251</option>
	<option value="Chuknagar-9252" >Chuknagar-9252</option>

</select>

<select class="Khulna Phultala"  >

	<option value="Phultala-9210" selected >Phultala-9210 </option>

</select>

<select class="Khulna Paikgachha"  >

	<option value="" selected>Select a post </option>
	<option value="Paikgachha-9280"  >Paikgachha-9280 </option>
	<option value="Katipara-9283"  >Katipara-9283 </option>
	<option value="Kapilmoni-9282"  >Kapilmoni-9282 </option>
	<option value="Godaipur-9281"  >Godaipur-9281 </option>
	<option value="Chandkhali-9284"  >Chandkhali-9284</option>
	<option value="Garaikhali-9285"  >Garaikhali-9285 </option>

</select>

<select class="Khulna Madinabad"  >

	<option value="" selected>Select a post </option>
	<option value="Madinabad-9290"  >Madinabad-9290 </option>
	<option value="Amadee-9291"  >Amadee-9291</option>


</select>

<select class="Khulna Sadar"  >

	<option value="" selected>Select a post </option>
	<option value="Sonali-Jute-Mills-9206"  >Sonali-Jute-Mills-9206 </option>
	<option value="Siramani-9204"  >Siramani-9204</option>
	<option value="University-9208"  >University-9208</option>
	<option value="Shipyard-9201"  >Shipyard-9201</option>
	<option value="G.P.O-9000"  >G.P.O-9000</option>
	<option value="Sadar-9100"  >Khula Sadar-9100</option>
	<option value="Jahanabad-Canttonmen-9205"  >Jahanabad-Canttonmen-9205</option>
	<option value="Doulatpur-9202"  >Doulatpur-9202</option>
	<option value="BIT-9203"  >BIT-9203</option>
	<option value="Atra-Shilpa-Area-9207"  >Atra-Shilpa-Area-9207</option>


</select>

<select class="Khulna Digalia"  >

	<option value="" selected>Select a post </option>
	<option value="Senhati-9222"  >Senhati-9222 </option>
	<option value="Ghoshghati-9223"  >Ghoshghati-9223</option>
	<option value="Gazirhat-9224"  >Gazirhat-9224</option>
	<option value="Digalia-9220"  >Digalia-9220</option>
	<option value="Chandni Mahal-9221"  >Chandni Mahal-9221</option>


</select>

<select class="Khulna Chalna-Bazar"  >

	<option value="" selected>Select a post </option>
	<option value="Nalian-9273" >Nalian-9273 </option>
	<option value="Dakup-9271" >Dakup-9271 </option>
	<option value="Chalna Bazar-9270" >Chalna Bazar-9270 </option>
	<option value="Bajua-9272" >Bajua-9272 </option>

</select>

<select class="Khulna Batiaghat"  >

	<option value="" selected>Select a post </option>
	<option value="Surkalee-9261" >Surkalee-9261 </option>
	<option value="Batiaghat-9260" >Batiaghat-9260 </option>


</select>

<select class="Khulna Alaipur"  >


	<option value="" selected>Select a post </option>
	<option value="Alaipur-9240" >Alaipur-9240 </option>
	<option value="Rupsha-9241" >Rupsha-9241 </option>
	<option value="Belphulia-9242" >Belphulia-9242 </option>


</select>
<!---Kustia-->

<select class="Kustia Rafayetpur"  >


	<option value="" selected>Select a post </option>
	<option value="Taragunia-7051" >Taragunia-7051 </option>
	<option value="Rafayetpur-70501" >Rafayetpur-7050</option>
	<option value="Khasmathurapur-7052" >Khasmathurapur-7052</option>

</select>

<select class="Kustia Mirpur"  >


	<option value="" selected>Select a post </option>
	<option value="Poradaha-7031" >Poradaha-7031 </option>
	<option value="Mirpur-7030" >Mirpur-7030</option>
	<option value="Amla-Sadarpur-7032" >Amla-Sadarpur-7032</option>

</select>

<select class="Kustia Sadar"  >


	<option value="" selected>Select a post </option>
	<option value="Sadar-7000" >Sadar-7000 </option>
	<option value="Mohini-7001" >Mohini-7001</option>
	<option value="Jagati-7002">Jagati-7002</option>
	<option value="Islami-University-7003">Islami-University-7003</option>

</select>

<select class="Kustia Kumarkhali"  >

	<option value="" selected>Select a post </option>
	<option value="Panti-7011" >Panti-7011 </option>
	<option value="Kumarkhali-7010" >Kumarkhali-7010</option>

</select>

<select class="Kustia Janipur"  >

	<option value="" selected>Select a post </option>
	<option value="Khoksa-7021" >Khoksa-7021</option>
	<option value="Janipur-7020" >Janipur-7020</option>

</select>

<select class="Kustia Bheramara"  >

	<option value="" selected>Select a post </option>
	<option value="Ganges-Bheramara-7041" >Ganges-Bheramara-7041</option>
	<option value="Bheramara-7040" >Bheramara-7040</option>
	<option value="Allardarga-7042" >Allardarga-7042</option>

</select>
<!--Magura-->

<select class="Magura Shripur"  >

	<option value="" selected>Select a post </option>
	<option value="Shripur-7610" >Shripur-7610</option>
	<option value="Nachol-7612" >Nachol-7612</option>
	<option value="Langalbadh-7611" >Langalbadh-7611</option>

</select>

<select class="Magura Mohammadpur"  >

	<option value="" selected>Select a post </option>
	<option value="Nahata-7632" >Nahata-7632</option>
	<option value="Mohammadpur-7630" >Mohammadpur-7630</option>
	<option value="Langalbadh-7611" >Binodpur-7631</option>

</select>

<select class="Magura Sadar"  >

	<option value="Sadar-7600" selected>Sadar-7600</option>

</select>

<select class="Magura Arpara"  >

	<option value="Arpara-7620" selected>Arpara-7620</option>

</select>

<!--Meherpur-->

<select class="Magura Gangni"  >

	<option value="Gangni-7110" selected>Gangni-7110</option>

</select>

<select class="Magura Sadar"  >

	<option value="" selected>Select a post</option>
	<option value="Mujib-Nagar-Complex-7102" >Mujib-Nagar-Complex-7102</option>
	<option value="Meherpur Sadar-7100" >Meherpur Sadar-7100</option>
	<option value="Amjhupi-7152" >Amjhupi-7152</option>
	<option value="Amjhupi-7101" >Amjhupi-7101</option>

</select>

<!--Meherpur-->

<select class="Narail Sadar"  >

	<option value="" selected>Select a post</option>
	<option value="Ratanganj-7501" >Ratanganj-7501</option>
	<option value="Sadar-7500" >Sadar-7500</option>


</select>

<select class="Narail Mohajan"  >

	<option value="Mohajan-7521" selected>Mohajan-7521</option>

</select>

<select class="Narail Laxmipasha"  >

	<option value="" selected>Select a post</option>
	<option value="Naldi-7513" >Naldi-7513</option>
	<option value="Lohagora-7511" >Lohagora-7511</option>
	<option value="Laxmipasha-7510" >Laxmipasha-7510</option>
	<option value="Itna-7512" >Itna-7512</option>
	<option value="Baradia-7514" >Baradia-7514</option>


</select>

<select class="Narail Kalia"  >

	<option value="Kalia-7520" selected>Kalia-7520</option>

</select>

<!--Satkhira-->					

<select class="Satkhira Taala"   id="">
	<option value="0" selected>Select a post </option>
	<option value="Taala-9420" >Taala-9420</option>
	<option value="Patkelghata-9421" >Patkelghata-9421</option>
</select>

<select class="Satkhira Sadar"  >

	<option value="" selected>Select a post</option>
	<option value="Sadar-9400" >Sadar-9400</option>
	<option value="Islamia-Acc-9401" >Islamia-Acc-9401</option>
	<option value="Gunakar-kati-9402" >Gunakar-kati-9402</option>
	<option value="Budhhat-9403" >Budhhat-9403</option>


</select>

<select class="Satkhira Nakipur"  >

	<option value="" selected>Select a post</option>
	<option value="Noornagar-9451" >Noornagar-9451</option>
	<option value="Naobeki-9452" >Naobeki-9452</option>
	<option value="Nakipur-9450" >Nakipur-9450</option>
	<option value="Habinagar-9455" >Habinagar-9455</option>
	<option value="Gabura-9454" >Gabura-9454</option>
	<option value="Buri-Goalini-9453" >Buri-Goalini-9453</option>


</select>

<select class="Satkhira Kaliganj"  >

	<option value="" selected>Select a post</option>
	<option value="Ratanpur-9442" >Ratanpur-9442</option>
	<option value="Nalta-Mubaroknagar-9441" >Nalta-Mubaroknagar-9441</option>
	<option value="Kaliganj UPO-9440" >Kaliganj UPO-9440</option>


</select>	

<select class="Satkhira Kalaroa"  >

	<option value="" selected>Select a post</option>
	<option value="Murarikati-9411" >Murarikati-9411</option>
	<option value="Khordo-9414" >Khordo-9414</option>
	<option value="Kalaroa-9410" >Kalaroa-9410</option>
	<option value="Jhaudanga-9412" >Jhaudanga-9412</option>
	<option value="Hamidpur-9413" >Hamidpur-9413</option>
	<option value="Chandanpur-9415" >Chandanpur-9415</option>


</select>

<select class="Satkhira Debbhata"  >

	<option value="" selected>Select a post</option>
	<option value="Gurugram-9431" >Gurugram-9431</option>
	<option value="Debbhata-9430" >Debbhata-9430</option>

</select>

<select class="Satkhira Ashashuni"  >

	<option value="" selected>Select a post</option>
	<option value="Baradal-9461" >Baradal-9461</option>
	<option value="Ashashuni-9460" >Ashashuni-9460</option>

</select>	

<!--Dhaka-->	
<select class="Dhaka Uttara"  >

	<option value="Model-TwonTSO-1230" selected>Uttara Model TwonTSO</option>

</select>
<select class="Dhaka Tejgaon-Industrial-Area"  >

	<option value="Dhaka-Politechnic-1208" selected>Dhaka-Politechnic-1208</option>

</select>
<select class="Dhaka Tejgaon"  >

	<option value="TSO-1215" selected>TSO-1215</option>

</select>

<select class="Dhaka Sutrapur"  >

	<option value="" selected>Select a post</option>
	<option value="Wari-TSO-1203" >Wari-TSO-1203</option>
	<option value="Gendaria-TSO-1204" >Gendaria-TSO-1204</option>
	<option value="Dhaka Sadar HO-1100" >Dhaka Sadar HO-1100</option>

</select>

<select class="Dhaka Savar"  >

	<option value="" selected>Select a post</option>
	<option value="Shimulia-1345" >Shimulia-1345</option>
	<option value="P.A.T.C-1343" >P.A.T.C-1343</option>
	<option value="Savar-Canttonment-1344" >Savar Canttonment-1344</option>
	<option value="Savar-1340" >Savar-1340</option>
	<option value="Rajphulbaria-1347" >Rajphulbaria-1347</option>
	<option value="Kashem Cotton Mills-1346" >Kashem Cotton Mills-1346</option>
	<option value="Jahangirnagar Univer-1342" >Jahangirnagar Univer-1342</option>
	<option value="EPZ-1349" >EPZ-1349</option>
	<option value="Dairy Farm-1341" >Dairy Farm-1341</option>
	<option value="Amin Bazar-1348" >Amin Bazar-1348</option>

</select>

<select class="Dhaka Sabujbag"  >

	<option value="Basabo TSO-1214" selected>Basabo TSO-1214</option>

</select>

<select class="Dhaka Ramna"  >

	<option value="Shantinagr TSO-1217" selected>Shantinagr TSO-1217</option>

</select>

<select class="Dhaka Palton"  >

	<option value="Dhaka GPO-1000" selected>Dhaka GPO-1000</option>

</select>

<select class="Dhaka New-market"  >

	<option value="New Market TSO-1205" selected>New Market TSO-1205</option>

</select>

<select class="Dhaka Nawabganj"  >

	<option value="" selected>Select a post</option>
	<option value="Nawabganj-1320" >Nawabganj-1320</option>
	<option value="Khalpar-1324" >Khalpar-1324</option>
	<option value="Hasnabad-1321" >Hasnabad-1321</option>
	<option value="Daudpur-1322" >Daudpur-1322</option>
	<option value="Churain-1325" >Churain-1325</option>
	<option value="Agla-1323" >Agla-1323</option>
	<option value="Agla-1323" >Agla-1323</option>

</select>

<select class="Dhaka Motijheel"  >

	<option value="" selected>Select a post</option>
	<option value="DilkushaTSO-1223" >DilkushaTSO-1223</option>
	<option value="BangabhabanTSO-1222" >BangabhabanTSO-1222</option>

</select>

<select class="Dhaka Mohammadpur"  >

	<option value="" selected>Select a post</option>
	<option value="DilkushaTSO-1223" >Sangsad BhabanTSO-1225</option>
	<option value="Mohammadpur Housing-1207" >Mohammadpur Housing-1207</option>

</select>

<select class="Dhaka Mirpur"  >

	<option value="Mirpur TSO-1216" selected>Mirpur TSO-1216</option>

</select>

<select class="Dhaka Lalbag"  >

	<option value="Posta TSO-1211" selected>Posta TSO-1211</option>

</select>

<select class="Dhaka Khilkhet"  >

	<option value="KhilkhetTSO-1229" selected>KhilkhetTSO-1229</option>

</select>

<select class="Dhaka Khilgaon"  >

	<option value="KhilgaonTSO-1219" selected>KhilgaonTSO-1219</option>

</select>

<select class="Dhaka Keraniganj"  >

	<option value="" selected>Select a post </option>
	<option value="Keraniganj-1310" >Keraniganj-1310</option>
	<option value="Kalatia-1313" >Kalatia-1313</option>
	<option value="Dhaka Jute Mills-1311" >Dhaka Jute Mills-1311</option>
	<option value="Ati-1312" >Ati-1312</option>


</select>

<select class="Dhaka Joypara"  >

	<option value="" selected>Select a post </option>
	<option value="Palamganj-1331" >Palamganj-1331</option>
	<option value="Narisha-1332" >Narisha-1332</option>
	<option value="Joypara-1330" >Joypara-1330</option>

</select>

<select class="Dhaka Jatrabari"  >

	<option value="Dhania TSO-1232" selected>Dhania TSO-1232</option>

</select>

<select class="Dhaka Gulshan"  >

	<option value="" selected>Select a post </option>
	<option value="Gulshan Model Town-1212" >Gulshan Model Town-1212</option>
	<option value="Banani TSO-1213" >Banani TSO-1213</option>


</select>

<select class="Dhaka Dhanmondi"  >

	<option value="Jigatala TS-O1209" selected>Jigatala TS-O1209</option>

</select>

<select class="Dhaka Dhamrai"  >

	<option value="" selected>Select a post </option>
	<option value="Kamalpur-1351" >Kamalpur-1351</option>
	<option value="Dhamrai-1350" >Dhamrai-1350</option>


</select>

<select class="Dhaka Cantt"  >

	<option value="CantonmentTSO-1206" selected>Dhaka CantonmentTSO-1206</option>

</select>

<select class="Dhaka Demra"  >

	<option value="" selected>Select a post </option>
	<option value="Sarulia-1361">Sarulia-1361</option>
	<option value="Matuail-1362">Matuail-1362</option>
	<option value="Demra-1360">Demra-1360</option>

</select>

<select class="Faridpur Shriangan"  >

	<option value="Shriangan-7804" selected>Shriangan-7804 </option>
	

</select>

<select class="Faridpur Sadarpur"  >

	<option value="" selected>Select a post </option>
	<option value="Sadarpur-7820">Sadarpur-7820</option>
	<option value="Hat Krishapur-7821">Hat Krishapur-7821</option>
	<option value="Bishwa jaker Manjil-7822">Bishwa jaker Manjil-7822</option>

</select>

<select class="Faridpur Nagarkanda"  >

	<option value="" selected>Select a post </option>
	<option value="Talma-7841">Talma-7841</option>
	<option value="Nagarkanda-7840">Nagarkanda-7840</option>

</select>

<select class="Faridpur Madukhali"  >

	<option value="" selected>Select a post </option>
	<option value="Madukhali-78501">Madukhali-7850</option>
	<option value="Kamarkali-7851">Kamarkali-7851</option>

</select>

<select class="Faridpur Sadar" >

	<option value="" selected>Select a post </option>
	<option value="Kanaipur-7801">Kanaipur-7801</option>
	<option value="Faridpursadar-7800">Faridpursadar-7800</option>
	<option value="Baitulaman Politecni-7803">Baitulaman Politecni-7803</option>
	<option value="Ambikapur-7802">Ambikapur-7802</option>

</select>

<select class="Faridpur Charbadrashan" >

	<option value="Charbadrashan-7810" selected>Charbadrashan-7810</option>
	
</select>

<select class="Faridpur Bhanga" >

	<option value="Bhanga-7830" selected>Bhanga-7830</option>
	
</select>

<select class="Faridpur Alfadanga" >

	<option value="Alfadanga-7870" selected>Alfadanga-7870</option>
	
</select>

<select class="Faridpur Boalmari" >

	<option value="" selected>Select a post </option>
	<option value="Rupatpat-7861">Rupatpat-7861</option>
	<option value="Boalmari-7860">Boalmari-7860</option>

</select>
<!--Gazipur-->

<select class="Gazipur Sripur" >

	<option value="" selected>Select a post </option>
	<option value="Rajendrapur Canttome-1742">Rajendrapur Canttome-1742</option>
	<option value="Rajendrapur-1741">Rajendrapur-1741</option>

</select>

<select class="Gazipur Sreepur" >

	<option value="" selected>Select a post </option>
	<option value="Sreepur-1740">Sreepur-1740</option>
	<option value="Satkhamair-1744">Satkhamair-1744</option>
	<option value="Kawraid-1745">Kawraid-1745</option>
	<option value="Boubi-1748">Boubi-1748</option>
	<option value="Bashamur-1747">Bashamur-1747</option>
	<option value="Barmi-1743">Barmi-1743</option>

</select>

<select class="Gazipur Monnunagar" >

	<option value="" selected>Select a post </option>
	<option value="Nishat Nagar-1711">Nishat Nagar-1711</option>
	<option value="Monnunagar-1710">Monnunagar-1710</option>
	<option value="Ershad Nagar-1712">Ershad Nagar-1712</option>

</select>

<select class="Gazipur Kapashia" >

	<option value="kapashia-1730" selected>kapashia-1730 </option>
	
</select>

<select class="Gazipur Kaliganj" >

	<option value="" selected>Select a post </option>
	<option value="Vaoal Jamalpur-1723">Vaoal Jamalpur-1723</option>
	<option value="Santanpara-1722">Santanpara-1722</option>
	<option value="Pubail-1721">Pubail-1721</option>
	<option value="Kaliganj-1720">Kaliganj-1720</option>

</select>

<select class="Gazipur Kaliakaar" >

	<option value="" selected>Select a post </option>
	<option value="Safipur-1751">Safipur-1751</option>
	<option value="Kaliakaar-1750">Kaliakaar-1750</option>
	
</select>

<select class="Gazipur Sadar" >

	<option value="" selected>Select a post </option>
	<option value="National University-1704">National University-1704</option>
	<option value="Gazipur Sadar-1700">Gazipur Sadar-1700</option>
	<option value="Chandna-1702">Chandna-1702</option>
	<option value="B.R.R-1701">B.R.R-1701</option>
	<option value="B.O.F-1703 ">B.O.F-1703</option>
	
</select>

<!--Gopalgonj-->

<select class="Gopalganj Tungipara" >

	<option value="" selected>Select a post </option>
	<option value="Tungipara-8120">Tungipara-8120</option>
	<option value="Patgati-8121">Patgati-8121</option>

	
</select>

<select class="Gopalganj Maksudpur" >

	<option value="" selected>Select a post </option>
	<option value="Maksudpur-8140">Maksudpur-8140</option>
	<option value="Khandarpara-8142">Khandarpara-8142</option>
	<option value="Batkiamari-8141">Batkiamari-8141</option>

	
</select>


<select class="Gopalganj Kotalipara" >

	<option value="Kotalipara-8110" selected>Kotalipara-8110 </option>

</select>


<select class="Gopalganj Kashiani" >

	<option value="" selected>Select a post </option>
	<option value="Ratoil-8132">Ratoil-8132</option>
	<option value="Ramdia College-8131">Ramdia College-8131</option>
	<option value="Kashiani-8130">Kashiani-8130</option>
	<option value="Jonapur-8133">Jonapur-8133</option>

	
</select>

<select class="Gopalganj Sadar" >

	<option value="" selected>Select a post </option>
	<option value="Ulpur-8101">Ulpur-8101</option>
	<option value="Sadar-8100">Sadar-8100</option>
	<option value="Chandradighalia-8013">Chandradighalia-8013</option>
	<option value="Barfa-8102">Barfa-8102</option>

	
</select>

<!--JAMALPUR-->

<select class="Gopalganj Shorishabari" >

	<option value="" selected>Select a post </option>
	<option value="Shorishabari-2050">Shorishabari-2050</option>
	<option value="Pingna-2054">Pingna-2054</option>
	<option value="Jamuna Sar Karkhana-2055">Jamuna Sar Karkhana-2055</option>
	<option value="Jagannath Ghat-2053">Jagannath Ghat-2053</option>
	<option value="Gunerbari-2051">Gunerbari-2051</option>
	<option value="Bausee-2052">Bausee-2052</option>

	
</select>

<select class="Gopalganj Mathargonj" >

	<option value="" selected>Select a post </option>
	<option value="Mathargonj-2040">Mathargonj-2040</option>
	<option value="Balijhuri-2041">Balijhuri-2041</option>
	
</select>

<select class="Gopalganj Malandah" >

	<option value="" selected>Select a post </option>
	<option value="Malandah-2010">Malandah-2010</option>
	<option value="Malancha-2012">Malancha-2012</option>
	<option value="Mahmoodpur-2013">Mahmoodpur-2013</option>
	<option value="Jamalpur-2011">Jamalpur-2011</option>
	
</select>

<select class="Gopalganj Jamalpur" >

	<option value="" selected>Select a post </option>
	<option value="Narundi-2002">Narundi-2002</option>
	<option value="Nandina-2001">Nandina-2001</option>
	<option value="Jamalpur-2000">Jamalpur-2000</option>
	
</select>

<select class="Gopalganj Islampur" >

	<option value="" selected>Select a post </option>
	<option value="Islampur-2020">Islampur-2020</option>
	<option value="Gilabari-2022">Gilabari-2022</option>
	<option value="Durmoot-2021">Durmoot-2021</option>
	
</select>

<select class="Gopalganj Dewangonj" >

	<option value="" selected>Select a post </option>
	<option value="Dewangonj S. Mills-2031">Dewangonj S. Mills-2031</option>
	<option value="Dewangonj-2030">Dewangonj-2030</option>
	
</select>

<!--Kishoreganj-->

<select class="Kishoreganj Tarial" >

	<option value="Tarial-2316" selected>Tarial-2316 </option>

</select>

<select class="Kishoreganj Pakundia" >

	<option value="Pakundia-2326" selected>Pakundia-2326 </option>

</select>

<select class="Kishoreganj Ostagram" >

	<option value="Ostagram-2380" selected>Ostagram-2380 </option>

</select>

<select class="Kishoreganj Nikli" >

	<option value="Nikli-2360" selected>Nikli-2360 </option>

</select>

<select class="Kishoreganj Karimganj" >

	<option value="Karimganj-2310" selected>Karimganj-2310 </option>

</select>

<select class="Kishoreganj Itna" >

	<option value="Itna-2390" selected>Itna-2390 </option>

</select>

<select class="Kishoreganj Hossenpur" >

	<option value="Hossenpur-2320" selected>Hossenpur-2320 </option>

</select>

<select class="Kishoreganj Bhairab" >

	<option value="Bhairab-2350" selected>Bhairab-2350 </option>

</select>

<select class="Kishoreganj MIthamoin" >

	<option value="" selected>Select a post </option>
	<option value="MIthamoin-2370">MIthamoin-2370</option>
	<option value="Abdullahpur-2371">Abdullahpur-2371</option>
	
</select>

<select class="Kishoreganj Kuliarchar" >

	<option value="" selected>Select a post </option>
	<option value="Kuliarchar-2340">Kuliarchar-2340</option>
	<option value="Chhoysuti-2341">Chhoysuti-2341</option>
	
</select>

<select class="Kishoreganj Sadar" >

	<option value="" selected>Select a post </option>
	<option value="Nilganj-2303">Nilganj-2303</option>
	<option value="Maizhati-2302">Maizhati-2302</option>
	<option value="Kishoreganj Sadar-2300">Kishoreganj Sadar-2300</option>
	<option value="Kishoreganj S.Mills-2301">Kishoreganj S.Mills-2301</option>
	
</select>

<select class="Kishoreganj Katiadi" >

	<option value="" selected>Select a post </option>
	<option value="Katiadi-2330">Katiadi-2330</option>
	<option value="Gochhihata-2331">Gochhihata-2331</option>
	<option value="Kishoreganj Sadar-2300">Kishoreganj Sadar-2300</option>
	<option value="Kishoreganj S.Mills-2301">Kishoreganj S.Mills-2301</option>
	
</select>

<select class="Kishoreganj Bajitpur" >

	<option value="" selected>Select a post </option>
	<option value="Sararchar-2337">Sararchar-2337</option>
	<option value="Laksmipur-2338">Laksmipur-2338</option>
	<option value="Bajitpur-2336">Bajitpur-2336</option>
	
</select>

<!--Madaripur-->

<select class="Madaripur Rajoir" >

	<option value="" selected>Select a post </option>
	<option value="Rajoir-7910">Rajoir-7910</option>
	<option value="Khalia-7911">Khalia-7911</option>
	
</select>

<select class="Madaripur Sadar" >

	<option value="" selected>Select a post </option>
	<option value="Mustafapur-7904">Mustafapur-7904</option>
	<option value="Madaripur Sadar-7900">Madaripur Sadar-7900</option>
	<option value="Kulpaddi-7902">Kulpaddi-7902</option>
	<option value="Habiganj-7903">Habiganj-7903</option>
	<option value="Charmugria-7901">Charmugria-7901</option>
	
</select>

<select class="Madaripur Kalkini" >

	<option value="" selected>Select a post </option>
	<option value="Sahabrampur-7921">Sahabrampur-7921</option>
	<option value="Kalkini-7920">Kalkini-7920</option>
	
</select>

<select class="Madaripur Barhamganj" >

	<option value="" selected>Select a post </option>
	<option value="Umedpur-7933">Umedpur-7933</option>
	<option value="Nilaksmibandar-7931">Nilaksmibandar-7931</option>
	<option value="Barhamganj-7930">Barhamganj-7930</option>
	<option value="Bahadurpur-7932">Bahadurpur-7932</option>
	
</select>

<!--Manikganj-->

<select class="Manikganj Singair" >

	<option value="Singair-1820" selected>Singair-1820</option>
	
</select>

<select class="Manikganj Singair" >

	<option value="" selected>Select a post </option>
	<option value="Singair-1820">Singair-1820</option>
	<option value="joymantop-1822">joymantop-1822</option>
	<option value="Baira-1821">Baira-1821</option>
	<option value="Bahadurpur-7932">Bahadurpur-7932</option>
	
</select>

<select class="Manikganj Shibaloy" >

	<option value="" selected>Select a post </option>
	<option value="Uthli-1853">Uthli-1853</option>
	<option value="Tewta-1852">Tewta-1852</option>
	<option value="Shibaloy-1850">Shibaloy-1850</option>
	<option value="Aricha-1851">Aricha-1851</option>
	
</select>

<select class="Manikganj Saturia" >

	<option value="" selected>Select a post </option>
	<option value="Saturia-1810">Saturia-1810</option>
	<option value="Baliati-1811">Baliati-1811</option>
	
</select>

<select class="Manikganj Sadar" >

	<option value="" selected>Select a post </option>
	<option value="Sadar-1800">Sadar-1800</option>
	<option value="Manikganj Bazar-1801">Manikganj Bazar-1801</option>
	<option value="Mahadebpur-1803">Mahadebpur-1803</option>
	<option value="Gorpara-1802">Gorpara-1802</option>
	<option value="Barangail-1804">Barangail-1804</option>
	
</select>

<select class="Manikganj Lechhraganj" >

	<option value="" selected>Select a post </option>
	<option value="Lechhraganj-1830">Lechhraganj-1830</option>
	<option value="Jhitka-1831">Jhitka-1831</option>
	
</select>

<select class="Manikganj Gheor" >

	<option value="Gheor-1840" selected>Gheor-1840</option>
	
</select>

<select class="Manikganj Doulatpur" >

	<option value="Doulatpur-1860" selected>Doulatpur-1860</option>
	
</select>

<!--Munshiganj-->

<select class="Munshiganj Tangibari" >

	<option value="" selected>Select a post </option>
	<option value="Tangibari-1520">Tangibari-1520</option>
	<option value="Pura EDSO-1526">Pura EDSO-1526</option>
	<option value="Pura-1527">Pura-1527</option>
	<option value="Hasail-1524">Hasail-1524</option>
	<option value="Dighirpar-1525">Dighirpar-1525</option>
	<option value="Betkahat-1521">Betkahat-1521</option>
	<option value="Baligao-1522">Baligao-1522</option>
	<option value="Bajrajugini-1523">Bajrajugini-1523</option>
	
</select>

<select class="Munshiganj Srinagar" >

	<option value="" selected>Select a post </option>
	<option value="Vaggyakul SO-1556">Vaggyakul SO-1556</option>
	<option value="Srinagar-1550">Srinagar-1550</option>
	<option value="Mazpara-1552">Mazpara-1552</option>
	<option value="Kumarbhog-1555">Kumarbhog-1555</option>
	<option value="Kolapara-1554">Kolapara-1554</option>
	<option value="Hashara-1553">Hashara-1553</option>
	<option value="Bhaggyakul-1558">Bhaggyakul-1558</option>
	<option value="Barikhal-1551">Barikhal-1551</option>
	<option value="Baghra-1557">Baghra-1557</option>
	
</select>

<select class="Munshiganj Sirajdikhan" >

	<option value="" selected>Select a post </option>
	<option value="Sirajdikhan-1540">Sirajdikhan-1540</option>
	<option value="Shekher Nagar-1544">Shekher Nagar-1544</option>
	<option value="Malkha Nagar-1543">Malkha Nagar-1543</option>
	<option value="Kola-1541">Kola-1541</option>
	<option value="Ichapur-1542">Ichapur-1542</option>

	
</select>

<select class="Munshiganj Sadar" >

	<option value="" selected>Select a post </option>
	<option value="Rikabibazar-1501">Rikabibazar-1501</option>
	<option value="Munshiganj Sadar-1500">Munshiganj Sadar-1500</option>
	<option value="Mirkadim-1502">Mirkadim-1502</option>
	<option value="Kathakhali-1503">Kathakhali-1503</option>

	
</select>

<select class="Munshiganj Lohajong" >

	<option value="" selected>Select a post </option>
	<option value="Medini Mandal EDSO-1535">Medini Mandal EDSO-1535</option>
	<option value="Madini Mandal-1335">Madini Mandal-1335</option>
	<option value="Lohajang-1530">Lohajang-1530</option>
	<option value="Korhati-1531">Korhati-1531</option>
	<option value="Haridia DESO-1533">Haridia DESO-1533</option>
	<option value="Haridia-1333">Haridia-1333</option>
	<option value="Haldia SO-1532">Haldia SO-1532</option>
	<option value="Gouragonj-1534">Gouragonj-1534</option>

</select>

<select class="Munshiganj Gajaria" >

	<option value="" selected>Select a post </option>
	<option value="Rasulpur-1512">Rasulpur-1512</option>
	<option value="Hossendi-1511">Hossendi-1511</option>
	<option value="Gajaria-1510">Gajaria-1510</option>

</select>

<!--Mymensingh-->

<select class="Mymensingh Trishal" >

	<option value="" selected>Select a post </option>
	<option value="Trishal-2220">Trishal-2220</option>
	<option value="Ram Amritaganj-2222">Ram Amritaganj-2222</option>
	<option value="Dhala-2223">Dhala-2223</option>
	<option value="Ahmadbad-2221">Ahmadbad-2221</option>

</select>

<select class="Mymensingh Phulpur" >

	<option value="" selected>Select a post </option>
	<option value="Tarakanda-2252">Tarakanda-2252</option>
	<option value="Phulpur-2250">Phulpur-2250</option>
	<option value="Beltia-2251">Beltia-2251</option>

</select>

<select class="Mymensingh Nandail" >

	<option value="" selected>Select a post </option>
	<option value="Nandail-2290">Nandail-2290</option>
	<option value="Gangail-2291">Gangail-2291</option>
	<option value="Beltia-2251">Beltia-2251</option>

</select>

<select class="Mymensingh Sadar" >

	<option value="" selected>Select a post </option>
	<option value="Shombhuganj-2203">Shombhuganj-2203</option>
	<option value="Pearpur-2205">Pearpur-2205</option>
	<option value="Mymensingh Sadar-2200">Mymensingh Sadar-2200</option>
	<option value="Kawatkhali-2201">Kawatkhali-2201</option>
	<option value="Biddyaganj-2204">Biddyaganj-2204</option>
	<option value="Agriculture Universi-2202">Agriculture Universi-2202</option>

</select>

<select class="Mymensingh Muktagachha" >

	<option value="Muktagachha-2210" selected>Muktagachha-2210 </option>
	
</select>

<select class="Mymensingh Fulbaria" >

	<option value="Fulbaria-2216" selected>Fulbaria-2216 </option>
	
</select>

<select class="Mymensingh Bhaluka" >

	<option value="Bhaluka-2240" selected>Bhaluka-2240 </option>
	
</select>

<select class="Mymensingh Isshwargonj" >

	<option value="" selected>Select a post </option>
	<option value="Sohagi-2281">Sohagi-2281</option>
	<option value="Isshwargonj-2280">Isshwargonj-2280</option>
	<option value="Atharabari-2282">Atharabari-2282</option>

</select>

<select class="Mymensingh Haluaghat" >

	<option value="" selected>Select a post </option>
	<option value="Munshirhat-2262">Munshirhat-2262</option>
	<option value="Haluaghat-2260">Haluaghat-2260</option>
	<option value="Dhara-2261">Dhara-2261</option>

</select>

<select class="Mymensingh Gouripur" >

	<option value="" selected>Select a post </option>
	<option value="Ramgopalpur-2271">Ramgopalpur-2271</option>
	<option value="Gouripur-2270">Gouripur-2270</option>

</select>

<select class="Mymensingh Gaforgaon" >

	<option value="" selected>Select a post </option>
	<option value="Usti-2232">Usti-2232</option>
	<option value="Shibganj-2231">Shibganj-2231</option>
	<option value="Kandipara-2233">Kandipara-2233</option>
	<option value="Gaforgaon-2230">Gaforgaon-2230</option>
	<option value="Duttarbazar-2234">Duttarbazar-2234</option>

</select>

<!--Narayanganj-->

<select class="Narayanganj Siddirganj" >

	<option value="" selected>Select a post </option>
	<option value="Siddirganj-1430">Siddirganj-1430</option>
	<option value="LN Mills-1432">LN Mills-1432</option>
	<option value="Adamjeenagar-1431">Adamjeenagar-1431</option>

</select>

<select class="Narayanganj Rupganj" >

	<option value="" selected>Select a post </option>
	<option value="Rupganj-1460">Rupganj-1460</option>
	<option value="Nagri-1463">Nagri-1463</option>
	<option value="Murapara-1464">Murapara-1464</option>
	<option value="Kanchan-1461">Kanchan-1461</option>
	<option value="Bhulta-1462">Bhulta-1462</option>

</select>

<select class="Narayanganj Sadar" >

	<option value="Narayanganj Sadar-1400" selected>Narayanganj Sadar-1400</option>

</select>

<select class="Narayanganj Fatullah" >

	<option value="" selected>Select a post </option>
	<option value="Fatullah-1420">Fatullah-1420</option>
	<option value="Fatulla Bazar-1421">Fatulla Bazar-1421</option>

</select>

<select class="Narayanganj Bandar" >

	<option value="" selected>Select a post </option>
	<option value="Nabiganj-1412">Nabiganj-1412</option>
	<option value="Madanganj-1414">Madanganj-1414</option>
	<option value="D.C Mills-1411">D.C Mills-1411</option>
	<option value="BIDS-1413">BIDS-1413</option>
	<option value="Bandar-1410">Bandar-1410</option>

</select>

<select class="Narayanganj Baidder-Bazar" >

	<option value="" selected>Select a post </option>
	<option value="Barodi-1442">Barodi-1442</option>
	<option value="Bara Nagar-1441">Bara Nagar-1441</option>
	<option value="Baidder Bazar-1440">Baidder Bazar-1440</option>

</select>

<select class="Narayanganj Baidder-Bazar" >

	<option value="" selected>Select a post </option>
	<option value="Gopaldi-1451">Gopaldi-1451</option>
	<option value="Araihazar-1450">Araihazar-1450</option>

</select>

<!--Narshingdi-->

<select class="Narshingdi Belabo" >

	<option value="Belabo-1640" selected>Belabo-1640</option>

</select>

<select class="Narshingdi Shibpur" >

	<option value="Shibpur-1620" selected>Shibpur-1620</option>

</select>

<select class="Narshingdi Raypura" >

	<option value="" selected>Select a post </option>
	<option value="Raypura-1630">Raypura-1630</option>
	<option value="Radhaganj bazar-1632">Radhaganj bazar-1632</option>
	<option value="Bazar Hasnabad-1631">Bazar Hasnabad-1631</option>

</select>

<select class="Narshingdi Palash" >

	<option value="" selected>Select a post </option>
	<option value="Palash-1610">Palash-1610</option>
	<option value="Ghorashal Urea Facto-1611">Ghorashal Urea Facto-1611</option>
	<option value="Ghorashal-1613">Ghorashal-1613</option>
	<option value="Char Sindhur-1612">Char Sindhur-1612</option>

</select>

<select class="Narshingdi Sadar" >

	<option value="" selected>Select a post </option>
	<option value="UMC Jute Mills-1601">UMC Jute Mills-1601</option>
	<option value="Panchdona-1603">Panchdona-1603</option>
	<option value="Narshingdi Sadar-1600">Narshingdi Sadar-1600</option>
	<option value="Narshingdi College-1602">Narshingdi College-1602</option>
	<option value="Madhabdi-1604">Madhabdi-1604</option>
	<option value="Karimpur-1605">Karimpur-1605</option>

</select>

<select class="Narshingdi Monohordi" >

	<option value="" selected>Select a post </option>
	<option value="Monohordi-1650">Monohordi-1650</option>
	<option value="Katabaria-1652">Katabaria-1652</option>
	<option value="Hatirdia-1651">Hatirdia-1651</option>

</select>

<!--Netrakona-->

<select class="Netrakona Monohordi" >

	<option value="" selected>Select a post </option>
	<option value="Monohordi-1650">Monohordi-1650</option>
	<option value="Katabaria-1652">Katabaria-1652</option>
	<option value="Hatirdia-1651">Hatirdia-1651</option>

</select>

<select class="Netrakona Purbadhola" >

	<option value="" selected>Select a post </option>
	<option value="Shamgonj-2411">Shamgonj-2411</option>
	<option value="Purbadhola-2410">Purbadhola-2410</option>
	<option value="Jaria Jhanjhail-2412">Jaria Jhanjhail-2412</option>

</select>

<select class="Netrakona Sadar" >

	<option value="" selected>Select a post </option>
	<option value="Netrakona Sadar-2400">Netrakona Sadar-2400</option>
	<option value="Baikherhati-2401">Baikherhati-2401</option>

</select>

<select class="Netrakona Mohanganj" >

	<option value="Mohanganj-2446" selected>Mohanganj-2446 </option>

</select>

<select class="Netrakona Moddoynagar" >

	<option value="Moddoynagar-2456" selected>Moddoynagar-2456 </option>

</select>

<select class="Netrakona Madan" >

	<option value="Madan-2490" selected>Madan-2490 </option>

</select>

<select class="Netrakona Kendua" >

	<option value="Kendua-2480" selected>Kendua-2480 </option>

</select>

<select class="Netrakona Kalmakanda" >

	<option value="Kalmakanda-2430" selected>Kalmakanda-2430 </option>

</select>

<select class="Netrakona Dharampasha" >

	<option value="Dharampasha-2450" selected>Dharampasha-2450 </option>

</select>

<select class="Netrakona Barhatta" >

	<option value="Barhatta-2440" selected>Barhatta-2440 </option>

</select>

<select class="Netrakona Atpara" >

	<option value="Atpara-247" selected>Atpara-247 </option>

</select>

<select class="Netrakona Susnng-Durgapur" >

	<option value="Susnng Durgapur-2420" selected>Susnng Durgapur-2420</option>

</select>

<select class="Netrakona Sadar" >

	<option value="" selected>Select a post </option>
	<option value="Netrakona Sadar-2400">Netrakona Sadar-2400</option>
	<option value="Baikherhati-2401">Baikherhati-2401</option>

</select>

<select class="Netrakona Khaliajhri" >

	<option value="" selected>Select a post </option>
	<option value="Shaldigha-2462">Shaldigha-2462</option>
	<option value="Khaliajhri-2460">Khaliajhri-2460</option>

</select>

<select class="Netrakona Dhobaura" >

	<option value="" selected>Select a post </option>
	<option value="Sakoai-2417">Sakoai-2417</option>
	<option value="Dhobaura-2416">Dhobaura-2416</option>

</select>

<!--Rajbari-->

<select class="Rajbari Sadar" >

	<option value="" selected>Select a post </option>
	<option value="Rajbari Sadar-7700">Rajbari Sadar-7700</option>
	<option value="Khankhanapur-7711">Khankhanapur-7711</option>
	<option value="Goalanda-7710">Goalanda-7710</option>

</select>

<select class="Rajbari Pangsha" >

	<option value="" selected>Select a post </option>
	<option value="Ratandia-7722">Ratandia-7722</option>
	<option value="Ramkol-7721">Ramkol-7721</option>
	<option value="Pangsha-7720">Pangsha-7720</option>
	<option value="Mrigibazar-7723">Mrigibazar-7723</option>

</select>

<select class="Rajbari Baliakandi" >

	<option value="" selected>Select a post </option>
	<option value="Nalia-7731">Nalia-7731</option>
	<option value="Baliakandi-7730">Baliakandi-7730</option>

</select>

<!--Shariatpur-->

<select class="Shariatpur Sadar" >

	<option value="" selected>Select a post </option>
	<option value="Shariatpur Sadar-8000">Shariatpur Sadar-8000</option>
	<option value="Chikandi-8002">Chikandi-8002</option>
	<option value="Angaria-8001">Angaria-8001</option>

</select>

<select class="Shariatpur Naria" >

	<option value="" selected>Select a post </option>
	<option value="Upshi-8023">Upshi-8023</option>
	<option value="Naria-8020">Naria-8020</option>
	<option value="Kartikpur-8024">Kartikpur-8024</option>
	<option value="Gharisar-8022">Gharisar-8022</option>
	<option value="Bhozeshwar-8021">Bhozeshwar-8021</option>

</select>

<select class="Shariatpur Jajira" >

	<option value="Jajira-8010" selected>Jajira-8010 </option>

</select>

<select class="Shariatpur Gosairhat" >

	<option value="Gosairhat-8050" selected>Gosairhat-8050 </option>

</select>

<select class="Shariatpur Damudhya" >

	<option value="Damudhya-8040" selected>Damudhya-8040 </option>

</select>

<select class="Shariatpur Bhedorganj" >

	<option value="Bhedorganj-8030" selected>Bhedorganj-8030 </option>

</select>

<!--Sherpur-->

<select class="Sherpur Shribardi" >

	<option value="Shribardi-2130" selected>Shribardi-2130 </option>

</select>

<select class="Sherpur Shadar" >

	<option value="Sherpur Shadar-2100" selected>Sherpur Shadar-2100 </option>

</select>

<select class="Sherpur Jhinaigati" >

	<option value="Jhinaigati-2120" selected>Jhinaigati-2120 </option>

</select>

<select class="Sherpur Bakshigonj" >

	<option value="Bakshigonj-2140" selected>Bakshigonj-2140 </option>

</select>

<select class="Sherpur Nalitabari" >

	<option value="" selected>Select a post </option>
	<option value="Nalitabari-2110">Nalitabari-2110</option>
	<option value="Hatibandha-2111">Hatibandha-2111</option>

</select>

<select class="Sherpur Nakla" >

	<option value="" selected>Select a post </option>
	<option value="Nakla-2150">Nakla-2150</option>
	<option value="Gonopaddi-2151">Gonopaddi-2151</option>

</select>

<!--Tangail-->

<select class="Tangail Sadar" >

	<option value="" selected>Select a post </option>
	<option value="Tangail Sadar-1900">Tangail Sadar-1900</option>
	<option value="Santosh-1902">Santosh-1902</option>
	<option value="Purabari-1904">Purabari-1904</option>
	<option value="Korotia-1903">Korotia-1903</option>
	<option value="Kagmari-1901">Kagmari-1901</option>

</select>

<select class="Tangail Sakhipur" >

	<option value="" selected>Select a post </option>
	<option value="Sakhipur-1950">Sakhipur-1950</option>
	<option value="Kochua-1951">Kochua-1951</option>

</select>

<select class="Tangail Nagarpur" >

	<option value="" selected>Select a post </option>
	<option value="Salimabad-1938">Salimabad-1938</option>
	<option value="Nagarpur-1936">Nagarpur-1936</option>
	<option value="Dhuburia-1937">Dhuburia-1937</option>

</select>

<select class="Tangail Mirzapur" >

	<option value="" selected>Select a post </option>
	<option value="Warri paikpara-1943">Warri paikpara-1943</option>
	<option value="Mohera-1945">Mohera-1945</option>
	<option value="Mirzapur-1940">Mirzapur-1940</option>
	<option value="M.C. College-1942">M.C. College-1942</option>
	<option value="Jarmuki-1944">Jarmuki-1944</option>
	<option value="Gorai-1941">Gorai-1941</option>

</select>

<select class="Tangail Madhupur" >

	<option value="" selected>Select a post </option>
	<option value="Madhupur-1996">Madhupur-1996</option>
	<option value="Dhobari-1997">Dhobari-1997</option>

</select>

<select class="Tangail Kashkawlia" >

	<option value="Kashkawlia-1930" selected>Kashkawlia-1930 </option>

</select>

<select class="Tangail Bhuapur" >

	<option value="Bhuapur-1960" selected>Bhuapur-1960</option>

</select>

<select class="Tangail Bhuapur" >

	<option value="Basail-1920" selected>Basail-1920</option>

</select>

<select class="Tangail Madhupur" >

	<option value="" selected>Select a post </option>
	<option value="Rajafair-1971">Rajafair-1971</option>
	<option value="Palisha-1975">Palisha-1975</option>
	<option value="Nagbari-1972">Nagbari-1972</option>
	<option value="Nagbari-1972">Nagarbari SO-1976</option>
	<option value="Nagarbari-1977">Nagarbari-1977</option>
	<option value="Kalihati-1970">Kalihati-1970</option>
	<option value="Elinga-1974">Elinga-1974</option>
	<option value="Ballabazar-1973">Ballabazar-1973</option>

</select>

<select class="Tangail Madhupur" >

	<option value="" selected>Select a post </option>
	<option value="Jhowail-1991">Jhowail-1991</option>
	<option value="Hemnagar-1992">Hemnagar-1992</option>
	<option value="Gopalpur-1990">Gopalpur-1990</option>

</select>

<select class="Tangail Ghatail" >

	<option value="" selected>Select a post </option>
	<option value="Zahidganj-1981">Zahidganj-1981</option>
	<option value="Lohani-1984">Lohani-1984</option>
	<option value="Ghatail-1980">Ghatail-1980</option>
	<option value="Dhalapara-1983">Dhalapara-1983</option>
	<option value="D. Pakutia-1982">D. Pakutia-1982</option>

</select>

<select class="Tangail Delduar" >

	<option value="" selected>Select a post </option>
	<option value="Patharail-1912">Patharail-1912</option>
	<option value="Lowhati-1915">Lowhati-1915</option>
	<option value="Jangalia-1911">Jangalia-1911</option>
	<option value="Hinga Nagar-1914">Hinga Nagar-1914</option>
	<option value="Elasin-1913">Elasin-1913</option>
	<option value="Delduar-1910">Delduar-1910</option>

</select>

<!--Bandarban-->

<select class="Bandarban Thanchi" >

	<option value="" selected>Select a post </option>
	<option value="Thanchi-4630">Thanchi-4630</option>
	<option value="Lama-4641">Lama-4641</option>
	
</select>

<select class="Bandarban Ruma" >

	<option value="Ruma-4620" selected>Ruma-4620 </option>

</select>

<select class="Bandarban Roanchhari" >

	<option value="Roanchhari-4610" selected>Roanchhari-4610 </option>

</select>

<select class="Bandarban Naikhong" >

	<option value="Naikhong-4660" selected>Naikhong-4660</option>

</select>

<select class="Bandarban Sadar" >

	<option value="Bandarban Sadar-4600" selected>Bandarban Sadar-4600</option>

</select>

<select class="Bandarban Alikadam" >

	<option value="Alikadam-4650" selected>Alikadam-4650</option>

</select>

<!--Brahmanbaria-->

<select class="Brahmanbaria Sarail" >

	<option value="" selected>Select a post </option>
	<option value="Shahbajpur-3431">Shahbajpur-3431</option>
	<option value="Sarial-3430">Sarial-3430</option>
	<option value="Chandura-34320">Chandura-3432</option>
	
</select>

<select class="Brahmanbaria Nasirnagar" >

	<option value="" selected>Select a post </option>
	<option value="Nasirnagar-3440">Nasirnagar-3440</option>
	<option value="Fandauk-3441">Fandauk-3441</option>
	
</select>

<select class="Brahmanbaria Nabinagar" >

	<option value="" selected>Select a post </option>
	<option value="Shamgram-3413">Shamgram-3413</option>
	<option value="Shahapur-3415">Shahapur-3415</option>
	<option value="Salimganj-3418">Salimganj-3418</option>
	<option value="Ratanpur-3414">Ratanpur-3414</option>
	<option value="Nabinagar-3410">Nabinagar-3410</option>
	<option value="Laubfatehpur-3411">Laubfatehpur-3411</option>
	<option value="Kaitala-3417">Kaitala-3417</option>
	<option value="Jibanganj-3419">Jibanganj-3419</option>
	
</select>

<select class="Brahmanbaria Kasba" >

	<option value="" selected>Select a post </option>
	<option value="Kuti-3461">Kuti-3461</option>
	<option value="Kasba-3460">Kasba-3460</option>
	<option value="Gopinathpur-3464">Gopinathpur-3464</option>
	<option value="Chargachh-3463">Chargachh-3463</option>
	<option value="Chandidar-3462">Chandidar-3462</option>

</select>

<select class="Brahmanbaria Kasba" >

	<option value="" selected>Select a post </option>
	<option value="Talshahar-3401">Talshahar-3401</option>
	<option value="Poun-3404">Poun-3404</option>
	<option value="Brahamanbaria Sadar-3400">Brahamanbaria Sadar-3400</option>
	<option value="Ashuganj Share-3403">Ashuganj Share-3403</option>
	<option value="Ashuganj-3402">Ashuganj-3402</option>

</select>


<select class="Brahmanbaria Banchharampur" >

	<option value="Banchharampur-3420" selected>Banchharampur-3420</option>

</select>

<select class="Brahmanbaria Kasba" >

	<option value="" selected>Select a post </option>
	<option value="Gangasagar-3452">Gangasagar-3452</option>
	<option value="Azampur-3451">Azampur-3451</option>
	<option value="Akhaura-3450">Akhaura-3450</option>

</select>

<!--Chandpur-->

<select class="Chandpur Shahrasti" >

	<option value="" selected>Select a post </option>
	<option value="Shahrasti-3620">Shahrasti-3620</option>
	<option value="Pashchim Kherihar Al-3622">Pashchim Kherihar Al-3622</option>
	<option value="Khilabazar-3621">Khilabazar-3621</option>
	<option value="Islamia Madrasha-3624">Islamia Madrasha-3624</option>
	<option value="Chotoshi-3623">Chotoshi-3623</option>

</select>

<select class="Chandpur Matlobganj" >

	<option value="" selected>Select a post </option>
	<option value="Mohanpur-3641">Mohanpur-3641</option>
	<option value="Matlobganj-3640">Matlobganj-3640</option>
	<option value="Kalipur-3642">Kalipur-3642</option>

</select>

<select class="Chandpur Kachua" >

	<option value="" selected>Select a post </option>
	<option value="Shachar-3633">Shachar-3633</option>
	<option value="Rahima Nagar-3632">Rahima Nagar-3632</option>
	<option value="Pak Shrirampur-3631">Pak Shrirampur-3631</option>
	<option value="Kachua-3630">Kachua-3630</option>

</select>

<select class="Chandpur Hayemchar" >

	<option value="" selected>Select a post </option>
	<option value="Hayemchar-3660">Hayemchar-3660</option>
	<option value="Gandamara-3661">Gandamara-3661</option>

</select>

<select class="Chandpur Hajiganj" >

	<option value="" selected>Select a post </option>
	<option value="Hajiganj-3610">Hajiganj-3610</option>
	<option value="Bolakhal-3611">Bolakhal-3611</option>

</select>

<select class="Chandpur Faridganj" >

	<option value="" selected>Select a post </option>
	<option value="Rupsha-3652">Rupsha-3652</option>
	<option value="Rampurbazar-3654">Rampurbazar-3654</option>
	<option value="Islampur Shah Isain-3655">Islampur Shah Isain-3655</option>
	<option value="Gridkaliandia-3653">Gridkaliandia-3653</option>
	<option value="Faridganj-3650">Faridganj-3650</option>
	<option value="Chandra-3651">Chandra-3651</option>

</select>


<select class="Chandpur Sadar" >

	<option value="" selected>Select a post </option>
	<option value="Sahatali-3603">Sahatali-3603</option>
	<option value="Puranbazar-3601">Puranbazar-3601</option>
	<option value="Chandpur Sadar-3600">Chandpur Sadar-3600</option>
	<option value="Baburhat-3602">Baburhat-3602</option>

</select>

<!--Chittagong-->

<select class="Chittagong Sitakunda" >

	<option value="" selected>Select a post </option>
	<option value="Sitakunda-4310">Sitakunda-4310</option>
	<option value="Kumira-4314">Kumira-4314</option>
	<option value="Jafrabad-4317">Jafrabad-4317</option>
	<option value="Fouzdarhat-4316">Fouzdarhat-4316</option>
	<option value="Bhatiari-4315">Bhatiari-4315</option>
	<option value="Bawashbaria-4313">Bawashbaria-4313</option>
	<option value="Baroidhala-4311">Baroidhala-4311</option>
	<option value="Barabkunda-4312">Barabkunda-4312</option>

</select>

<select class="Chittagong Satkania" >

	<option value="" selected>Select a post </option>
	<option value="Satkania-4386">Satkania-4386</option>
	<option value="Bazalia-4388">Bazalia-4388</option>
	<option value="Baitul Ijjat-4387">Baitul Ijjat-4387</option>

</select>

<select class="Chittagong Satkania" >

	<option value="" selected>Select a post </option>
	<option value="Urirchar-4302">Urirchar-4302</option>
	<option value="Shiberhat-4301">Shiberhat-4301</option>
	<option value="Sandwip-4300">Sandwip-4300</option>

</select>

<select class="Chittagong Rouzan" >

	<option value="" selected>Select a post </option>
	<option value="Rouzan-4340">Rouzan-4340</option>
	<option value="Mohamuni-4348">Mohamuni-4348</option>
	<option value="Kundeshwari-4342">Kundeshwari-4342</option>
	<option value="jagannath Hat-4344">jagannath Hat-4344</option>
	<option value="Guzra Noapara-4346">Guzra Noapara-4346</option>
	<option value="Gahira-4343">Gahira-4343</option>
	<option value="Fatepur-4345">Fatepur-4345</option>
	<option value="Dewanpur-4347">Dewanpur-4347</option>
	<option value="Beenajuri-4341">Beenajuri-4341</option>
	<option value="Beenajuri-4341">B.I.T Post Office-4349</option>

</select>

<select class="Chittagong Rangunia" >

	<option value="" selected>Select a post </option>
	<option value="Rangunia-4360">Rangunia-4360</option>
	<option value="Dhamair-4361">Dhamair-4361</option>
	
</select>

<select class="Chittagong Patiya" >

	<option value="" selected>Select a post </option>
	<option value="Patiya Head Office-43700">Patiya Head Office-4370</option>
	<option value="Budhpara-4371">Budhpara-4371</option>
	
</select>

<select class="Chittagong Mirsharai" >

	<option value="" selected>Select a post </option>
	<option value="Mohazanhat-4328">Mohazanhat-4328</option>
	<option value="Mirsharai-4320">Mirsharai-4320</option>
	<option value="Korerhat-4327">Korerhat-4327</option>
	<option value="Joarganj-4324">Joarganj-4324</option>
	<option value="Darrogahat-4322">Darrogahat-4322</option>
	<option value="Bharawazhat-4323">Bharawazhat-4323</option>
	<option value="Azampur-4325">Azampur-4325</option>
	<option value="Abutorab-4321">Abutorab-4321</option>
	
</select>

<select class="Chittagong Lohagara" >

	<option value="" selected>Select a post </option>
	<option value="Padua-4397">Padua-4397</option>
	<option value="Lohagara-4396">Lohagara-4396</option>
	<option value="Chunti-4398">Chunti-4398</option>
	
</select>

<select class="Chittagong Jaldi" >

	<option value="" selected>Select a post </option>
	<option value="Khan Bahadur-4391">Khan Bahadur-4391</option>
	<option value="Jaldi-4390">Jaldi-4390</option>
	<option value="Gunagari-4392">Gunagari-4392</option>
	<option value="Banigram-4393">Banigram-4393</option>
	
</select>


<select class="Chittagong Hathazari" >

	<option value="" selected>Select a post </option>
	<option value="Yunus Nagar-4338">Yunus Nagar-4338</option>
	<option value="Nuralibari-4337">Nuralibari-4337</option>
	<option value="Mirzapur-4334">Mirzapur-4334</option>
	<option value="Madrasa-4339">Madrasa-4339</option>
	<option value="Katirhat-4333">Katirhat-4333</option>
	<option value="Hathazari-4330">Hathazari-4330</option>
	<option value="Gorduara-4332">Gorduara-4332</option>
	<option value="Fatahabad-4335">Fatahabad-4335</option>
	<option value="Chitt.University-4331">Chitt.University-4331</option>
	
</select>

<select class="Chittagong Fatikchhari" >

	<option value="" selected>Select a post </option>
	<option value="Narayanhat-4355">Narayanhat-4355</option>
	<option value="Nanupur-4351">Nanupur-4351</option>
	<option value="Najirhat-4353">Najirhat-4353</option>
	<option value="Harualchhari-4354">Harualchhari-4354</option>
	<option value="Fatikchhari-4350">Fatikchhari-4350</option>
	<option value="Bhandar Sharif-4352">Bhandar Sharif-4352</option>

	
</select>

<select class="Chittagong East-Joara" >

	<option value="" selected>Select a post </option>
	<option value="Gachbaria-4381">Gachbaria-4381</option>
	<option value="East-Joara-4380">East-Joara-4380</option>
	<option value="Dohazari-4382">Dohazari-4382</option>
	<option value="Dohazari-4382">Barma-4383</option>

</select>

<select class="Chittagong Sadar" >

	<option value="" selected>Select a post </option>
	<option value="Wazedia-4213">Wazedia-4213</option>
	<option value="Rampura TSO-4224">Rampura TSO-4224</option>
	<option value="Patenga-4204">Patenga-4204</option>
	<option value="Pahartoli-4202">Pahartoli-4202</option>
	<option value="North Katuli-4217">North Katuli-4217</option>
	<option value="North Halishahar-4226">North Halishahar-4226</option>
	<option value="Mohard-4208">Mohard-4208</option>
	<option value="Middle Patenga-4222">Middle Patenga-4222</option>
	<option value="Jaldia Merine Accade-4206">Jaldia Merine Accade-4206</option>
	<option value="Jalalabad-4214">Jalalabad-4214</option>
	<option value="Halishshar-4225">Halishshar-4225</option>
	<option value="Halishahar-4216">Halishahar-4216</option>
	<option value="Firozshah-4207">Firozshah-4207</option>
	<option value="Export Processing-4223">Export Processing-4223</option>
	<option value="Chittagong GPO-4000">Chittagong GPO-4000</option>
	<option value="Chittagong Bandar-4100">Chittagong Bandar-4100</option>
	<option value="Chittagong Airport-4205">Chittagong Airport-4205</option>
	<option value="Chitt. Sailers Colon-4218">Chitt. Sailers Colon-4218</option>
	<option value="Chitt. Politechnic In-4209">Chitt. Politechnic In-4209</option>
	<option value="Chitt. Customs Acca-4219">Chitt. Customs Acca-4219</option>
	<option value="Chitt. Cantonment-4220">Chitt. Cantonment-4220</option>
	<option value="Chawkbazar-4203">Chawkbazar-4203</option>
	<option value="Chandgaon-4212">Chandgaon-4212</option>
	<option value="Bayezid Bostami-4210">Bayezid Bostami-4210</option>
	<option value="Anandabazar-4215">Anandabazar-4215</option>
	<option value="Anandabazar-4215">Amin Jute Mills-4211</option>
	<option value="Al- Amin Baria Madra-4221">Al- Amin Baria Madra-4221</option>

</select>


<select class="Chittagong Boalkhali" >

	<option value="" selected>Select a post </option>
	<option value="Saroatoli-4364">Saroatoli-4364</option>
	<option value="Sakpura-4367">Sakpura-4367</option>
	<option value="Kanungopara-4363">Kanungopara-4363</option>
	<option value="Kadurkhal-4368">Kadurkhal-4368</option>
	<option value="Iqbal Park-4365">Iqbal Park-4365</option>
	<option value="Charandwip-4369">Charandwip-4369</option>
	<option value="Boalkhali-4366">Boalkhali-4366</option>

</select>


<select class="Chittagong Anowara" >

	<option value="" selected>Select a post </option>
	<option value="Paroikora-4377">Paroikora-4377</option>
	<option value="Battali-4378">Battali-4378</option>
	<option value="Anowara-4376">Anowara-4376</option>

</select>

<!--Comilla-->

<select class="Comilla Muradnagar" >

	<option value="" selected>Select a post </option>
	<option value="Sonakanda-3544">Sonakanda-3544</option>
	<option value="Ramchandarpur-3541">Ramchandarpur-3541</option>
	<option value="Pantibazar-3545">Pantibazar-3545</option>
	<option value="Muradnagar-3540">Muradnagar-3540</option>
	<option value="Companyganj-3542">Companyganj-3542</option>
	<option value="Bangra-3543">Bangra-3543</option>

</select>

<select class="Comilla Langalkot" >

	<option value="" selected>Select a post </option>
	<option value="Langalkot-3580">Langalkot-3580</option>
	<option value="Gunabati-3583">Gunabati-3583</option>
	<option value="Dhalua-3581">Dhalua-3581</option>
	<option value="Chhariabazar-3582">Chhariabazar-3582</option>
	
</select>

<select class="Comilla Laksam" >

	<option value="" selected>Select a post </option>
	<option value="Lakshamanpur-3571">Lakshamanpur-3571</option>
	<option value="Laksam-3570">Laksam-3570</option>
	<option value="Bipulasar-3572">Bipulasar-3572</option>
	<option value="Chhariabazar-3582">Chhariabazar-3582</option>
	
</select>

<select class="Comilla Homna" >

	<option value="Homna-3546" selected>Homna-3546 </option>
	
</select>

<select class="Comilla Brahmanpara" >

	<option value="Brahmanpara-3526" selected>Brahmanpara-3526 </option>
	
</select>

<select class="Comilla Davidhar" >

	<option value="" selected>Select a post </option>
	<option value="Gangamandal-3531">Gangamandal-3531</option>
	<option value="Dhamtee-3533">Dhamtee-3533</option>
	<option value="Davidhar-3530">Davidhar-3530</option>
	<option value="Barashalghar-3532">Barashalghar-3532</option>
	
</select>

<select class="Comilla Daudkandi" >

	<option value="" selected>Select a post </option>
	<option value="Gouripur-3517">Gouripur-3517</option>
	<option value="Eliotganj-3519">Eliotganj-3519</option>
	<option value="Daudkandi-3516">Daudkandi-3516</option>
	<option value="Dashpara-3518">Dashpara-3518</option>
	
</select>

<select class="Comilla Sadar" >

	<option value="" selected>Select a post </option>
	<option value="Suaganj-3504">Suaganj-3504</option>
	<option value="Halimanagar-3502">Halimanagar-3502</option>
	<option value="Courtbari-3503">Courtbari-3503</option>
	<option value="Comilla Sadar-3500">Comilla Sadar-3500</option>
	<option value="Comilla Contoment-3501">Comilla Contoment-3501</option>
	
</select>

<select class="Comilla Chouddagram" >

	<option value="" selected>Select a post </option>
	<option value="Chouddagram-3550">Chouddagram-3550</option>
	<option value="Chiora-3552">Chiora-3552</option>
	<option value="Batisa-3551">Batisa-3551</option>
	
</select>

<select class="Comilla Chandia" >

	<option value="" selected>Select a post </option>
	<option value="Madhaiabazar-3511">Madhaiabazar-3511</option>
	<option value="Chandia-3510">Chandia-3510</option>
	
</select>

<select class="Comilla Burichang" >

	<option value="" selected>Select a post </option>
	<option value="Maynamoti bazar-3521">Maynamoti bazar-3521</option>
	<option value="Burichang-3520">Burichang-3520</option>
	
</select>

<select class="Comilla Barura" >

	<option value="" selected>Select a post </option>
	<option value="Poyalgachha-3561">Poyalgachha-3561</option>
	<option value="Murdafarganj-3562">Murdafarganj-3562</option>
	<option value="Barura-3560">Barura-3560</option>
	
</select>
<select class="Comilla Burichang" >

	<option value="" selected>Select a post </option>
	<option value="Maynamoti bazar-3521">Maynamoti bazar-3521</option>
	<option value="Burichang-3520">Burichang-3520</option>
	
</select>

<!--Cox’s Bazar-->

<select class="Coxs-Bazar Ramu">

	<option value="Ramu-4730" selected>Ramu-4730</option>
	
</select>

<select class="Coxs-Bazar Kutubdia">

	<option value="Kutubdia-4720" selected>Kutubdia-4720</option>
	
</select>

<select class="Coxs-Bazar Gorakghat">

	<option value="Gorakghat-4710" selected>Gorakghat-4710</option>
	
</select>

<select class="Coxs-Bazar Ukhia">

	<option value="Ukhia-4750" selected>Ukhia-4750</option>
	
</select>

<select class="Coxs-Bazar Teknaf">

	<option value="" selected>Select a post </option>
	<option value="Teknaf-4760">Teknaf-4760</option>
	<option value="St.Martin-4762">St.Martin-4762</option>
	<option value="Hnila-4761">Hnila-4761</option>
	
</select>

<select class="Coxs-Bazar Sadar">

	<option value="" selected>Select a post </option>
	<option value="Zhilanja-4701">Zhilanja-4701</option>
	<option value="Eidga-4702">Eidga-4702</option>
	<option value="Coxs Bazar Sadar-4700">Coxs Bazar Sadar-4700</option>
	
</select>

<select class="Coxs-Bazar Teknaf">

	<option value="" selected>Select a post </option>
	<option value="Malumghat-4743">Malumghat-4743</option>
	<option value="Chiringga S.O-4741">Chiringga S.O-4741</option>
	<option value="Chiringga-4740">Chiringga-4740</option>
	<option value="Badarkali-4742">Badarkali-4742</option>
	
</select>

<!--Feni-->

<select class="Feni Sonagazi">

	<option value="" selected>Select a post </option>
	<option value="Sonagazi-3930">Sonagazi-3930</option>
	<option value="Motiganj-3931">Motiganj-3931</option>
	<option value="Kazirhat-3933">Kazirhat-3933</option>
	<option value="Ahmadpur-3932">Ahmadpur-3932</option>
	
</select>

<select class="Feni Pashurampur">

	<option value="" selected>Select a post </option>
	<option value="Shuarbazar-3941">Shuarbazar-3941</option>
	<option value="Pashurampur-39401">Pashurampur-3940</option>
	<option value="Munshirhat-3943">Munshirhat-3943</option>
	<option value="Fulgazi-3942">Fulgazi-3942</option>
	
</select>

<select class="Feni Sadar">

	<option value="" selected>Select a post </option>
	<option value="Sharshadie-3902">Sharshadie-3902</option>
	<option value="Laskarhat-3903">Laskarhat-3903</option>
	<option value="Feni Sadar-3900">Feni Sadar-3900</option>
	<option value="Fazilpur-3901">Fazilpur-3901</option>
	
</select>

<select class="Feni Dagonbhuia">

	<option value="" selected>Select a post </option>
	<option value="Rajapur-3923">Rajapur-3923</option>
	<option value="Dudmukha-3921">Dudmukha-3921</option>
	<option value="Dagonbhuia-3920">Dagonbhuia-3920</option>
	<option value="Chhilonia-3922">Chhilonia-3922</option>
	
</select>

<select class="Feni Dagonbhuia">

	<option value="" selected>Select a post </option>
	<option value="Puabashimulia-3913">Puabashimulia-3913</option>
	<option value="Maharajganj-3911">Maharajganj-3911</option>
	<option value="Daraga Hat-3912">Daraga Hat-3912</option>
	<option value="Chhagalnaia-3910">Chhagalnaia-3910</option>
	
</select>

<!--Khagrachari-->

<select class="Khagrachari Ramghar-Head-Office">

	<option value="Ramghar Head Office-4440" selected>Ramghar Head Office-4440 </option>
	
</select>
<select class="Khagrachari Panchhari">

	<option value="Panchhari-4410" selected>Panchhari-4410</option>
	
</select>
<select class="Khagrachari Matiranga">

	<option value="Matiranga-4450" selected>Matiranga-4450</option>
	
</select>
<select class="Khagrachari Manikchhari">

	<option value="Manikchhari-4460" selected>Manikchhari-4460</option>
	
</select>

<select class="Khagrachari Mahalchhari">

	<option value="Mahalchhari-4430" selected>Mahalchhari-4430</option>
	
</select>

<select class="Khagrachari Laxmichhari">

	<option value="Laxmichhari-4470" selected>Laxmichhari-4470</option>
	
</select>
<select class="Khagrachari Sadar">

	<option value="Khagrachari Sadar-4400" selected>Khagrachari Sadar-4400</option>
	
</select>

<select class="Khagrachari Diginala">

	<option value="Diginala-4420" selected>Diginala-4420</option>
	
</select>

<!--Lakshmipur-->

<select class="Lakshmipur Raypur">

	<option value="" selected>Select a post </option>
	<option value="Raypur-3710">Raypur-3710</option>
	<option value="Rakhallia-3711">Rakhallia-3711</option>
	<option value="Nagerdighirpar-3712">Nagerdighirpar-3712</option>
	<option value="Haydarganj-3713">Haydarganj-3713</option>
	<option value="Bhuabari-3714">Bhuabari-3714</option>
	
</select>

<select class="Lakshmipur Ramganj">

	<option value="" selected>Select a post </option>
	<option value="Ramganj-3720">Ramganj-3720</option>
	<option value="Panpara-3722">Panpara-3722</option>
	<option value="Naagmud-3724">Naagmud-3724</option>
	<option value="Kanchanpur-3723">Kanchanpur-3723</option>
	<option value="Dolta-3725">Dolta-3725</option>
	<option value="Alipur-3721">Alipur-3721</option>
	
</select>

<select class="Lakshmipur  Sadar">

	<option value="" selected>Select a post </option>
	<option value="Rupchara-3705">Rupchara-3705</option>
	<option value="Mandari-3703">Mandari-3703</option>
	<option value="Lakshimpur Sadar-3700">Lakshimpur Sadar-3700</option>
	<option value="Keramatganj-3704">Keramatganj-3704</option>
	<option value="Duttapara-3706">Duttapara-3706</option>
	<option value="Dalal Bazar-3701">Dalal Bazar-3701</option>
	<option value="Choupalli-3707">Choupalli-3707</option>
	<option value="Chandraganj-3708">Chandraganj-3708</option>
	<option value="Bhabaniganj-3702">Bhabaniganj-3702</option>
	<option value="Amani Lakshimpur-3709">Amani Lakshimpur-3709</option>
	
</select>

<select class="Lakshmipur  Char-Alexgander">

	<option value="" selected>Select a post </option>
	<option value="Ramgatirhat-3732">Ramgatirhat-3732</option>
	<option value="Hajirghat-3731">Hajirghat-3731</option>
	<option value="Char Alexgander-3730">Char Alexgander-3730</option>

	
</select>

<!--Noakhali-->

<select class="Noakhali  Senbag">

	<option value="" selected>Select a post </option>
	<option value="T.P. Lamua-3865">T.P. Lamua-3865</option>
	<option value="Senbag-3860">Senbag-3860</option>
	<option value="Kankirhat-3863">Kankirhat-3863</option>
	<option value="Kallyandi-3861">Kallyandi-3861</option>
	<option value="Chatarpaia-3864">Chatarpaia-3864</option>
	<option value="Beezbag-3862">Beezbag-3862</option>

</select>

<select class="Noakhali  Sadar">

	<option value="" selected>Select a post </option>
	<option value="Sonapur-3802">Sonapur-3802</option>
	<option value="Pak Kishoreganj-3804">Pak Kishoreganj-3804</option>
	<option value="Noakhali Sadar-3800">Noakhali Sadar-3800</option>
	<option value="Noakhali College-3801">Noakhali College-3801</option>
	<option value="Mriddarhat-3806">Mriddarhat-3806</option>
	<option value="Khalifar Hat-3808">Khalifar Hat-3808</option>
	<option value="Kabirhat-3807">Kabirhat-3807</option>
	<option value="Din Monir Hat-3803">Din Monir Hat-3803</option>
	<option value="Charam Tua-3809">Charam Tua-3809</option>
	<option value="Char Jabbar-3812">Char Jabbar-3812</option>
	<option value="Chaprashir Hat-3811">Chaprashir Hat-3811</option>

</select>

<select class="Noakhali  Hatiya">

	<option value="" selected>Select a post </option>
	<option value="Tamoraddi-3892">Tamoraddi-3892</option>
	<option value="Hatiya-3890">Hatiya-3890</option>
	<option value="Afazia-3891">Afazia-3891</option>

</select>

<select class="Noakhali  Chatkhil">

	<option value="" selected>Select a post </option>
	<option value="Solla-3875">Solla-3875</option>
	<option value="Shingbahura-3883">Shingbahura-3883</option>
	<option value="Sampara-3882">Sampara-3882</option>
	<option value="Sahapur-3881">Sahapur-3881</option>
	<option value="Rezzakpur-3874">Rezzakpur-3874</option>
	<option value="Palla-3871">Palla-3871</option>
	<option value="Khilpara-3872">Khilpara-3872</option>
	<option value="Karihati-3877">Karihati-3877</option>
	<option value="Dosh Gharia-3878">Dosh Gharia-3878</option>
	<option value="Chatkhil-3870">Chatkhil-3870</option>
	<option value="Bodalcourt-3873">Bodalcourt-3873</option>
	<option value="Bansa Bazar-3879">Bansa Bazar-3879</option>

</select>

<select class="Noakhali  Begumganj">

	<option value="" selected>Select a post </option>
	<option value="Thanar Hat-3845">Thanar Hat-3845</option>
	<option value="Tangirpar-3832">Tangirpar-3832</option>
	<option value="Sonaimuri-3827">Sonaimuri-3827</option>
	<option value="Rajganj-3834">Rajganj-3834</option>
	<option value="Oachhekpur-3835">Oachhekpur-3835</option>
	<option value="Nandiapara-3841">Nandiapara-3841</option>
	<option value="Nadona-3839">Nadona-3839</option>
	<option value="Mir Owarishpur-3823">Mir Owarishpur-3823</option>
	<option value="Maheshganj-3838">Maheshganj-3838</option>
	<option value="Khalishpur-3842">Khalishpur-3842</option>
	<option value="Khalafat Bazar-3833">Khalafat Bazar-3833</option>
	<option value="Joynarayanpur-3829">Joynarayanpur-3829</option>
	<option value="Joyag-3844">Joyag-3844</option>
	<option value="Jamidar Hat-3825">Jamidar Hat-3825</option>
	<option value="Gopalpur-3828">Gopalpur-3828</option>
	<option value="Durgapur-3848">Durgapur-3848</option>
	<option value="Dauti-3843">Dauti-3843</option>
	<option value="Choumohani-3821">Choumohani-3821</option>
	<option value="Bhabani Jibanpur-3837">Bhabani Jibanpur-3837</option>
	<option value="Begumganj-3820">Begumganj-3820</option>
	<option value="Bazra-3824">Bazra-3824</option>
	<option value="Banglabazar-3822">Banglabazar-3822</option>
	<option value="Amisha Para-3847">Amisha Para-3847</option>
	<option value="Alaiarpur-3831">Alaiarpur-3831</option>

</select>

<select class="Noakhali Basurhat" id="">
	<option value="" select>Select a post </option>
	<option value="Charhajari-3851">Charhajari-3851</option>
	<option value="Basur Hat-3850">Basur Hat-3850</option>
</select>

<!--Rangamati-->

<select class="Rangamati Sadar" id="">

	<option value="Rangamati Sadar-4500" select>Rangamati Sadar-4500 </option>

</select>

<select class="Rangamati Rajsthali" id="">

	<option value="Rajsthali-4540" select>Rajsthali-4540</option>

</select>

<select class="Rangamati Naniachhar" id="">

	<option value="Nanichhar-4520" select>Nanichhar-4520</option>

</select>

<select class="Rangamati Marishya" id="">

	<option value="Marishya-4590" select>Marishya-4590</option>

</select>

<select class="Rangamati Longachh" id="">

	<option value="Longachh-4580" select>Longachh-4580</option>

</select>

<select class="Rangamati Jarachhari" id="">

	<option value="Jarachhari-4560" select>Jarachhari-4560</option>

</select>

<select class="Rangamati Bilaichhari" id="">

	<option value="Bilaichhari-4550" select>Bilaichhari-4550</option>

</select>

<select class="Rangamati Barakal" id="">

	<option value="Barakal-4570" select>Barakal-4570</option>

</select>

<select class="Rangamati Kaptai" id="">
	<option value="" select>Select a post </option>
	<option value="Kaptai Project-4532">Kaptai Project-4532</option>
	<option value="Nuton Bazar-4533">Nuton Bazar-4533</option>
	<option value="Kaptai-4530">Kaptai-4530</option>
	<option value="Chandraghona-4531">Chandraghona-4531</option>
</select>

<select class="Rangamati Kalampati" id="">
	<option value="" select>Select a post </option>
	<option value="Kalampati-4510">Kalampati-4510</option>
	<option value="Betbunia-4511">Betbunia-4511</option>
	<option value="Kaptai-4530">Kaptai-4530</option>
	<option value="Chandraghona-4531">Chandraghona-4531</option>
</select>

<!--Hobiganj-->

<select class="Hobiganj Nabiganj" id="">
	<option value="" select>Select a post </option>
	<option value="Nabiganj-3370">Nabiganj-3370</option>
	<option value="Inathganj-3374">Inathganj-3374</option>
	<option value="Goplarbazar-3371">Goplarbazar-3371</option>
	<option value="Golduba-3372">Golduba-3372</option>
	<option value="Digalbak-3373">Digalbak-3373</option>
</select>

<select class="Hobiganj Madhabpur" id="">

	<option value="" select>Select a post </option>
	<option value="Shahajibazar-3332">Shahajibazar-3332</option>
	<option value="Saihamnagar-3333">Saihamnagar-3333</option>
	<option value="Madhabpur-3330">Madhabpur-3330</option>
	<option value="Itakhola-3331">Itakhola-3331</option>
	
</select>

<select class="Hobiganj Kalauk" id="">

	<option value="" select>Select a post </option>
	<option value="Lakhai-3341">Lakhai-3341</option>
	<option value="Kalauk-3340">Kalauk-3340</option>
	
</select>

<select class="Hobiganj Sadar" id="">

	<option value="" select>Select a post </option>
	<option value="Shaestaganj-3301">Shaestaganj-3301</option>
	<option value="Hobiganj Sadar-3300">Hobiganj Sadar-3300</option>
	<option value="Gopaya-3302">Gopaya-3302</option>
	
</select>

<select class="Hobiganj Chunarughat" id="">

	<option value="" select>Select a post </option>
	<option value="Narapati-3322">Narapati-3322</option>
	<option value="Chunarughat-3320">Chunarughat-3320</option>
	<option value="Chandpurbagan-3321">Chandpurbagan-3321</option>
	
</select>

<select class="Hobiganj Baniachang" id="">

	<option value="" select>Select a post </option>
	<option value="Kadirganj-3352">Kadirganj-3352</option>
	<option value="Jatrapasha-3351">Jatrapasha-3351</option>
	<option value="Baniachang-3350">Baniachang-3350</option>
	
</select>

<select class="Hobiganj Bahubal" id="">

	<option value="Bahubal-3310" select>Bahubal-3310 </option>
	
</select>

<select class="Hobiganj Azmireeganj" id="">

	<option value="Azmireeganj-3360" select>Azmireeganj-3360 </option>
	
</select>

<!--Moulvibazar-->

<select class="Moulvibazar Rajnagar" id="">

	<option value="Rajnagar-3240" select>Rajnagar-3240 </option>
	
</select>

<select class="Moulvibazar Srimangal" id="">

	<option value="" select>Select a post </option>
	<option value="Srimangal-3210">Srimangal-3210</option>
	<option value="Satgaon-3214">Satgaon-3214</option>
	<option value="Narain Chora-3211">Narain Chora-3211</option>
	<option value="Khejurichhara-3213">Khejurichhara-3213</option>
	<option value="Kalighat-3212">Kalighat-3212</option>
	
</select>

<select class="Moulvibazar Sadar" id="">

	<option value="" select>Select a post </option>
	<option value="Moulvibazar Sadar-3200">Moulvibazar Sadar-3200</option>
	<option value="Monumukh-3202">Monumukh-3202</option>
	<option value="Barakapan-3201">Barakapan-3201</option>
	<option value="Afrozganj-3203">Afrozganj-3203</option>
	
</select>

<select class="Moulvibazar Kulaura" id="">

	<option value="" select>Select a post </option>
	<option value="Tillagaon-3231">Tillagaon-3231</option>
	<option value="Prithimpasha-3233">Prithimpasha-3233-3202</option>
	<option value="Langla-3232">Langla-3232</option>
	<option value="Kulaura-3230">Kulaura-3230</option>
	<option value="Karimpur-3235">Karimpur-3235</option>
	<option value="Kajaldhara-3234">Kajaldhara-3234</option>
	<option value="Baramchal-3237">Baramchal-3237</option>
	
</select>

<select class="Moulvibazar Kulaura" id="">

	<option value="" select>Select a post </option>
	<option value="Shamsher Nagar-3223">Shamsher Nagar-3223</option>
	<option value="Patrakhola-3222">Patrakhola-3222</option>
	<option value="Munshibazar-3224">Munshibazar-3224</option>
	<option value="Keramatnaga-3221">Keramatnaga-3221</option>
	<option value="Kamalganj-3220">Kamalganj-3220</option>
	
</select>

<select class="Moulvibazar Kulaura" id="">

	<option value="" select>Select a post </option>
	<option value="Purbashahabajpur-3253">Purbashahabajpur-3253</option>
	<option value="Juri-3251">Juri-3251</option>
	<option value="Dhakkhinbag-3252">Dhakkhinbag-3252</option>
	<option value="Baralekha-3250">Baralekha-3250</option>
	
</select>

<!--Sunamganj-->

<select class="Sunamganj Tahirpur" id="">

	<option value="Tahirpur-3030" select>Tahirpur-3030</option>
	
</select>

<select class="Sunamganj Sachna" id="">

	<option value="Sachna-3020" select>Sachna-3020</option>
	
</select>

<select class="Sunamganj Ghungiar" id="">

	<option value="Ghungiar-3050" select>Ghungiar-3050</option>
	
</select>

<select class="Sunamganj Duara-bazar" id="">

	<option value="Duara bazar-3070" select>Duara bazar-3070</option>
	
</select>

<select class="Sunamganj Bishamsarpur" id="">

	<option value="Bishamsapur-3010" select>Bishamsapur-3010</option>
	
</select>

<select class="Sunamganj Kulaura" id="">

	<option value="" select>Select a post </option>
	<option value="Sunamganj Sadar-3000">Sunamganj Sadar-3000</option>
	<option value="Patharia-3002">Patharia-3002</option>
	<option value="Pagla-3001">Pagla-3001</option>
	
</select>

<select class="Sunamganj Jagnnathpur" id="">

	<option value="" select>Select a post </option>
	<option value="Syedpur-3061">Syedpur-3061</option>
	<option value="Shiramsi-3065">Shiramsi-3065</option>
	<option value="Rasulganj-3064">Rasulganj-3064</option>
	<option value="Jagnnathpur-3060">Jagnnathpur-3060</option>
	<option value="Hasan Fatemapur-3063">Hasan Fatemapur-3063</option>
	<option value="Atuajan-3062">Atuajan-3062</option>
	
</select>

<select class="Sunamganj Dhirai-Chandpur" id="">

	<option value="" select>Select a post </option>
	<option value="Jagdal-3041">Jagdal-3041</option>
	<option value="Dhirai Chandpur-3040">Dhirai Chandpur-3040</option>
	
</select>

<select class="Sunamganj Dhirai-Chandpur" id="">

	<option value="" select>Select a post </option>
	<option value="Moinpur-3086">Moinpur-3086</option>
	<option value="Khurma-3085">Khurma-3085</option>
	<option value="jahidpur-3087">jahidpur-3087</option>
	<option value="Islamabad-3088">Islamabad-3088</option>
	<option value="Gabindaganj Natun Ba-3084">Gabindaganj Natun Ba-3084</option>
	<option value="Gabindaganj-3083">Gabindaganj-3083</option>
	<option value="Chourangi Bazar-3893">Chourangi Bazar-3893</option>
	<option value="Paper Mills-3082">Paper Mills-3082</option>
	<option value="Cement Facto-3081">Cement Facto-3081</option>
	<option value="Chhatak-3080">Chhatak-3080</option>
	
</select>

<!--Sylhet-->

<select class="Sylhet Kompanyganj" id="">

	<option value="Kompanyganj-3140" select>Kompanyganj-3140 </option>

</select>

<select class="Sylhet Jaintapur" id="">

	<option value="Jainthapur-3156" select>Jainthapur-3156</option>

</select>
	

<select class="Sylhet Sadar" id="">

	<option value="" select>Select a post </option>
	<option value="Cadet Col-3101">Cadet Col-3101</option>
	<option value="Biman Bondar-3102">Biman Bondar-3102</option>
	<option value="Sylhe Sadar-3100">Sylhe Sadar-3100</option>
	<option value="Silam-3105">Silam-3105</option>
	<option value="Shahajalal Science-3114">Shahajalal Science-3114</option>
	<option value="Ranga Hajiganj-3109">Ranga Hajiganj-3109</option>
	<option value="Mogla-3108">Mogla-3108</option>
	<option value="Lalbazar-3113">Lalbazar-3113</option>
	<option value="Khadimnagar-3103">Khadimnagar-3103</option>
	<option value="Kamalbazer-3112">Kamalbazer-3112</option>
	<option value="Kadamtali-3111">Kadamtali-3111</option>
	<option value="Jalalabad-3107">Jalalabad-3107</option>
	<option value="Birahimpur-3106">Birahimpur-3106</option>
	
</select>

<select class="Sylhet Kanaighat" id="">

	<option value="" select>Select a post </option>
	<option value="Manikganj-3182">Manikganj-3182</option>
	<option value="Kanaighat-3180">Kanaighat-3180</option>
	<option value="Gachbari-3183">Gachbari-3183</option>
	<option value="Chatulbazar-3181">Chatulbazar-3181</option>
	
</select>

<select class="Sylhet Jakiganj" id="">

	<option value="" select>Select a post </option>
	<option value="Jakiganj-3190">Jakiganj-3190</option>
	<option value="Ichhamati-3191">Ichhamati-3191</option>
	
</select>

<select class="Sylhet Gopalganj" id="">

	<option value="" select>Select a post </option>
	<option value="Ranaping-3163">Ranaping-3163</option>
	<option value="Gopalgannj-3160">Gopalgannj-3160</option>
	<option value="Dhaka Dakkhin-3161">Dhaka Dakkhin-3161</option>
	<option value="Dakkhin Bhadashore-3162">Dakkhin Bhadashore-3162</option>
	<option value="Chandanpur-3165">Chandanpur-3165</option>
	<option value="banigram-3164">banigram-3164</option>
	
</select>

<select class="Sylhet Goainhat" id="">

	<option value="" select>Select a post </option>
	<option value="Jaflong-3151">Jaflong-3151</option>
	<option value="Goainhat-3150">Goainhat-3150</option>
	<option value="Chiknagul-3152">Chiknagul-3152</option>
	
</select>

<select class="Sylhet Fenchuganj" id="">

	<option value="" select>Select a post </option>
	<option value="Fenchuganj SareKarkh-3117">Fenchuganj SareKarkh-3117</option>
	<option value="Fenchuganj-3116">Fenchuganj-3116</option>
	
</select>

<select class="Sylhet Bishwanath" id="">

	<option value="" select>Select a post </option>
	<option value="Singer kanch-3134">Singer kanch-3134</option>
	<option value="Doulathpur-3132">Doulathpur-3132</option>
	<option value="Deokalas-3133">Deokalas-3133</option>
	<option value="Dashghar-3131">Dashghar-3131</option>
	<option value="Bishwanath-3130">Bishwanath-3130</option>
	
</select>

<select class="Sylhet Bianibazar" id="">

	<option value="" select>Select a post </option>
	<option value="Salia bazar-3174">Salia bazar-3174</option>
	<option value="Mathiura-3172">Mathiura-3172</option>
	<option value="Kurar bazar-3173">Kurar bazar-3173</option>
	<option value="jaldup-3171">jaldup-3171</option>
	<option value="Churkai-3175">Churkai-3175</option>
	<option value="Bianibazar-3170">Bianibazar-3170</option>
	
</select>

<select class="Sylhet Bianibazar" id="">

	<option value="" select>Select a post </option>
	<option value="Tajpur-3123">Tajpur-3123</option>
	<option value="Omarpur-3126">Omarpur-3126</option>
	<option value="Natun Bazar-3129">Natun Bazar-3129</option>
	<option value="Kathal Khair-3127">Kathal Khair-3127</option>
	<option value="Karua-3121">Karua-3121</option>
	<option value="Goala Bazar-3124">Goala Bazar-3124</option>
	<option value="Gaharpur-3128">Gaharpur-3128</option>
	<option value="Brahman Shashon-3122">Brahman Shashon-3122</option>
	<option value="Begumpur-3125">Begumpur-3125</option>
	<option value="Balaganj-3120">Balaganj-3120</option>
	
</select>

<!--Barguna-->

<select class="Barguna Patharghata" id="">

	<option value="" select>Select a post </option>
	<option value="Patharghata-8720">Patharghata-8720</option>
	<option value="Kakchira-8721">Kakchira-8721</option>
	
</select>

<select class="Barguna Patharghata" id="">

	<option value="" select>Select a post </option>
	<option value="Patharghata-8720">Patharghata-8720</option>
	<option value="Kakchira-8721">Kakchira-8721</option>
	
</select>

<select class="Barguna Betagi" id="">

	<option value="" select>Select a post </option>
	<option value="Darul Ulam-8741">Darul Ulam-8741</option>
	<option value="Betagi-8740">Betagi-8740</option>
	
</select>

<select class="Barguna Sadar" id="">

	<option value="" select>Select a post </option>
	<option value="Nali Bandar-8701">Nali Bandar-8701</option>
	<option value="Barguna Sadar-8700">Barguna Sadar-8700</option>
	
</select>

<select class="Barguna Bamna" id="">

	<option value="Bamna-8730" select>Bamna-8730</option>

	
</select>

<select class="Barguna Amtali" id="">

	<option value="Amtali-8710" select>Amtali-8710</option>

	
</select>

<!--Barishal-->

<select class="Barishal Uzirpur" id="">

	<option value="" select>Select a post </option>
	<option value="Uzirpur-8220">Uzirpur-8220</option>
	<option value="Shikarpur-8224">Shikarpur-8224</option>
	<option value="Jugirkanda-8222">Jugirkanda-8222</option>
	<option value="Dhamura-8221">Dhamura-8221</option>
	<option value="Dakuarhat-8223">Dakuarhat-8223</option>
	
</select>

<select class="Barishal Sahebganj" id="">

	<option value="" select>Select a post </option>
	<option value="Shialguni-8283">Shialguni-8283</option>
	<option value="Sahebganj-8280">Sahebganj-8280</option>
	<option value="Padri Shibpur-8282">Padri Shibpur-8282</option>
	<option value="kalaskati-8284">kalaskati-8284</option>
	<option value="Charamandi-8281">Charamandi-8281</option>
	
</select>

<select class="Barishal Muladi" id="">

	<option value="" select>Select a post </option>
	<option value="Muladi-8250">Muladi-8250</option>
	<option value="Kazirchar-8251">Kazirchar-8251</option>
	<option value="Charkalekhan-8252">Charkalekhan-8252</option>
	
</select>

<select class="Barishal Mahendiganj" id="">

	<option value="" select>Select a post </option>
	<option value="Ulania-8272">Ulania-8272</option>
	<option value="Nalgora-8273">Nalgora-8273</option>
	<option value="Mahendiganj-8270">Mahendiganj-8270</option>
	<option value="Laskarpur-8271">Laskarpur-8271</option>
	<option value="Langutia-8274">Langutia-8274</option>
	
</select>

<select class="Barishal Gouranadi" id="">

	<option value="" select>Select a post </option>
	<option value="Tarki Bandar-8231">Tarki Bandar-8231</option>
	<option value="Kashemabad-8232">Kashemabad-8232</option>
	<option value="Gouranadi-8230">Gouranadi-8230</option>
	<option value="Batajor-8233">Batajor-8233</option>
	
</select>

<select class="Barishal Sadar" id="">

	<option value="" select>Select a post </option>
	<option value="Sugandia-8203">Sugandia-8203</option>
	<option value="Saheberhat-8202">Saheberhat-8202</option>
	<option value="Patang-8204">Patang-8204</option>
	<option value="Kashipur-8205">Kashipur-8205</option>
	<option value="Jaguarhat-8206">Jaguarhat-8206</option>
	<option value="Bukhainagar-8201">Bukhainagar-8201</option>
	<option value="Barishal Sadar-8200">Barishal Sadar-8200</option>
	
</select>

<select class="Barishal Barajalia" id="">

	<option value="" select>Select a post </option>
	<option value="Osman Manjil-8261">Osman Manjil-8261</option>
	<option value="Barajalia-8260">Barajalia-8260</option>
	
</select>

<select class="Barishal Babuganj" id="">

	<option value="" select>Select a post </option>
	<option value="Thakur Mallik-8214">Thakur Mallik-8214</option>
	<option value="Rahamatpur-8211">Rahamatpur-8211</option>
	<option value="Nizamuddin College-8215">Nizamuddin College-8215</option>
	<option value="Madhabpasha-8213">Madhabpasha-8213</option>
	<option value="Chandpasha-8212">Chandpasha-8212</option>
	<option value="Barishal Cadet-8216">Barishal Cadet-8216</option>
	<option value="Babuganj-8210">Babuganj-8210</option>
	
</select>

<select class="Barishal Babuganj" id="">

	<option value="" select>Select a post </option>
	<option value="Paisarhat-8242">Paisarhat-8242</option>
	<option value="Gaila-8241">Gaila-8241</option>
	<option value="Agailzhara-8240">Agailzhara-8240</option>
	
</select>

<!--Bhola-->

<select class="Bhola Lalmohan-UPO" id="">

	<option value="" select>Select a post </option>
	<option value="Lalmohan UPO-8330">Lalmohan UPO-8330</option>
	<option value="Gazaria-8332">Gazaria-8332</option>
	<option value="Daurihat-8331">Daurihat-8331</option>
	
</select>

<select class="Bhola Hatshoshiganj" id="">

	<option value="Hatshoshiganj-8350" select>Hatshoshiganj-8350 </option>
	
</select>

<select class="Bhola Hajirhat" id="">

	<option value="Hajirhat-8360" select>Hajirhat-8360</option>
	
</select>

<select class="Bhola Doulatkhan" id="">

	<option value="" select>Select a post </option>
	<option value="Hajipur-8311">Hajipur-8311</option>
	<option value="Doulatkhan-8310">Doulatkhan-8310</option>
	
</select>

<select class="Bhola Charfashion" id="">

	<option value="" select>Select a post </option>
	<option value="Keramatganj-8342">Keramatganj-8342</option>
	<option value="Dularhat-8341">Dularhat-8341</option>
	<option value="Charfashion-8340">Charfashion-8340</option>
	
</select>

<select class="Bhola Borhanuddin-UPO" id="">

	<option value="" select>Select a post </option>
	<option value="Mirzakalu-8321">Mirzakalu-8321</option>
	<option value="Borhanuddin UPO-8320">Borhanuddin UPO-8320</option>
	
</select>

<select class="Bhola Sadar" id="">

	<option value="" select>Select a post </option>
	<option value="Joynagar-8301">Joynagar-8301</option>
	<option value="Borhanuddin UPO-8320">Bhola Sadar-8300</option>
	
</select>

<!--Jhalokathi-->

<select class="Jhalokathi Rajapur" id="">

	<option value="Rajapur-8410" select>Rajapur-8410 </option>
	
</select>

<select class="Jhalokathi Nalchhiti" id="">

	<option value="" select>Select a post </option>
	<option value="Nalchhiti-8420">Nalchhiti-8420</option>
	<option value="Beerkathi-8421">Beerkathi-8421</option>
	
</select>

<select class="Jhalokathi Kathalia" id="">

	<option value="" select>Select a post </option>
	<option value="Shoulajalia-8433">Shoulajalia-8433</option>
	<option value="Niamatee-8432">Niamatee-8432</option>
	<option value="Kathalia-8430">Kathalia-8430</option>
	<option value="Amua-8431">Amua-8431</option>
	
</select>

<select class="Jhalokathi Sadar" id="">

	<option value="" select>Select a post </option>
	<option value="Shekherhat-8404">Shekherhat-8404</option>
	<option value="Nabagram-8401">Nabagram-8401</option>
	<option value="Jhalokathi Sadar-8400">Jhalokathi Sadar-8400</option>
	<option value="Gabha-8403">Gabha-8403</option>
	<option value="Baukathi-8402">Baukathi-8402</option>
	
</select>

<!--Patuakhali-->

<select class="Patuakhali Subidkhali" id="">

	<option value="Subidkhali-8610" select>Subidkhali-8610 </option>
	
</select>

<select class="Patuakhali Dashmina" id="">

	<option value="Dashmina-8630" select>Dashmina-8630 </option>
	
</select>

<select class="Patuakhali Sadar" id="">

	<option value="" select>Select a post </option>
	<option value="Rahimabad-8603">Rahimabad-8603</option>
	<option value="Patuakhali Sadar-8600">Patuakhali Sadar-8600</option>
	<option value="Moukaran-8601">Moukaran-8601</option>
	<option value="Dumkee-8602">Dumkee-8602</option>
	
</select>

<select class="Patuakhali Sadar" id="">

	<option value="" select>Select a post </option>
	<option value="Mahipur-8651">Mahipur-8651</option>
	<option value="Khepupara-8650">Khepupara-8650</option>
	
</select>

<select class="Patuakhali Sadar" id="">

	<option value="" select>Select a post </option>
	<option value="Gazipur Bandar-8641">Gazipur Bandar-8641</option>
	<option value="Galachipa-8640">Galachipa-8640</option>
	
</select>

<select class="Patuakhali Sadar" id="">

	<option value="" select>Select a post </option>
	<option value="Kalishari-8623">Kalishari-8623</option>
	<option value="Kalaia-8624">Kalaia-8624</option>
	<option value="Birpasha-8622">Birpasha-8622</option>
	<option value="Bauphal-8620">Bauphal-8620</option>
	<option value="Bagabandar-8621">Bagabandar-8621</option>
	
</select>

<!--Pirojpur-->

<select class="Pirojpur Swarupkathi" id="">

	<option value="" select>Select a post </option>
	<option value="Swarupkathi-8520">Swarupkathi-8520</option>
	<option value="Kaurikhara-8522">Kaurikhara-8522</option>
	<option value="Jalabari-8523">Jalabari-8523</option>
	<option value="Bauphal-8620">Darus Sunnat-8521</option>
	
</select>

<select class=" Pirojpur Sadar" id="">

	<option value="" select>Select a post </option>
	<option value="Pirojpur Sadar-8500">Pirojpur Sadar-8500</option>
	<option value="Parerhat-8502">Parerhat-8502</option>
	<option value="Hularhat-8501">Hularhat-8501</option>
	
</select>

<select class=" Pirojpur Sadar" id="">

	<option value="" select>Select a post </option>
	<option value="Sriramkathi-8541">Sriramkathi-8541</option>
	<option value="Nazirpur-8540">Nazirpur-8540</option>
	
</select>

<select class=" Pirojpur Mathbaria" id="">

	<option value="" select>Select a post </option>
	<option value="Tushkhali-8561">Tushkhali-8561</option>
	<option value="Tiarkhali-8564">Tiarkhali-8564</option>
	<option value="Shilarganj-8566">Shilarganj-8566</option>
	<option value="Mathbaria-8560">Mathbaria-8560</option>
	<option value="Halta-8562">Halta-8562</option>
	<option value="Gulishakhali-8563">Gulishakhali-8563</option>
	<option value="Betmor Natun Hat-8565">Betmor Natun Hat-8565</option>
	
</select>

<select class=" Pirojpur Kaukhali" id="">

	<option value="" select>Select a post </option>
	<option value="Keundia-8511">Keundia-8511</option>
	<option value="Kaukhali-8510">Kaukhali-8510</option>
	<option value="Joykul-8512">Joykul-8512</option>
	<option value="Jolagati-8513">Jolagati-8513</option>
	
</select>

<select class=" Pirojpur Bhandaria" id="">

	<option value="" select>Select a post </option>
	<option value="Kanudashkathi-8551">Kanudashkathi-8551</option>
	<option value="Dhaoa-8552">Dhaoa-8552</option>
	<option value="Bhandaria-8550">Bhandaria-8550</option>
	
</select>

<select class=" Pirojpur Banaripara" id="">

	<option value="" select>Select a post </option>
	<option value="Chakhar-8531">Chakhar-8531</option>
	<option value="Banaripara-8530">Banaripara-8530</option>
	
</select>

<!--Dinajpur-->

<select class="Dinajpur Setabganj" id="">

	<option value="Setabganj-5216" select>Setabganj-5216</option>
	
</select>

<select class="Dinajpur Phulbari" id="">

	<option value="Phulbari-5260" select>Phulbari-5260</option>
	
</select>

<select class="Dinajpur Parbatipur" id="">

	<option value="Parbatipur-5250" select>Parbatipur-5250</option>
	
</select>

<select class="Dinajpur Maharajganj" id="">

	<option value="Maharajganj-5226" select>Maharajganj-5226</option>
	
</select>

<select class="Dinajpur Birganj" id="">

	<option value="Birganj-5220" select>Birganj-5220</option>
	
</select>

<select class="Dinajpur Birampur" id="">

	<option value="Birampur-5266" select>Birampur-5266</option>
	
</select>

<select class="Dinajpur Biral" id="">

	<option value="Biral-5210" select>Biral-5210</option>
	
</select>

<select class="Dinajpur Bangla-Hili" id="">

	<option value="Bangla Hili-5270" select>Bangla Hili-5270</option>
	
</select>

<select class="Dinajpur Osmanpur" id="">

	<option value="" select>Select a post </option>
	<option value="Osmanpur-5290">Osmanpur-5290</option>
	<option value="Ghoraghat-5291">Ghoraghat-5291</option>
	
</select>

<select class="Dinajpur Nababganj" id="">

	<option value="" select>Select a post </option>
	<option value="Nababganj-5280">Nababganj-5280</option>
	<option value="Gopalpur-5282">Gopalpur-5282</option>
	<option value="Daudpur-5281">Daudpur-5281</option>
	
</select>

<select class="Dinajpur Khansama" id="">

	<option value="" select>Select a post </option>
	<option value="Pakarhat-5231">Pakarhat-5231</option>
	<option value="Khansama-5230">Khansama-5230</option>
	
</select>

<select class="Dinajpur Sadar" id="">

	<option value="" select>Select a post </option>
	<option value="Dinajpur Sadar-5200">Dinajpur Sadar-5200</option>
	<option value="Rajbari-5201">Rajbari-5201</option>
	
</select>

<select class="Dinajpur Chrirbandar" id="">

	<option value="" select>Select a post </option>
	<option value="Ranirbandar-5241">Ranirbandar-5241</option>
	<option value="Chrirbandar-5240">Chrirbandar-5240</option>
	
</select>

<!--Gaibandha-->

<select class="Gaibandha Sundarganj" id="">

	<option value="" select>Select a post </option>
	<option value="Sundarganj-5720">Sundarganj-5720</option>
	<option value="Bamandanga-5721">Bamandanga-5721</option>
	
</select>

<select class="Gaibandha Saadullapur" id="">

	<option value="" select>Select a post </option>
	<option value="Saadullapur-5710">Saadullapur-5710</option>
	<option value="Naldanga-5711">Naldanga-5711</option>
	
</select>

<select class="Gaibandha Phulchhari" id="">

	<option value="" select>Select a post </option>
	<option value="Phulchhari-5760">Phulchhari-5760</option>
	<option value="Bharatkhali-5761">Bharatkhali-5761</option>
	
</select>

<select class="Gaibandha Palashbari" id="">

	<option value="Palashbari-5730" select>Palashbari-5730 </option>
	
</select>

<select class="Gaibandha Gobindhaganj" id="">

	<option value="" select>Select a post </option>
	<option value="Gobindhaganj-5740">Gobindhaganj-5740</option>
	<option value="Mahimaganj-5741">Mahimaganj-5741</option>
	
</select>

<select class="Gaibandha Sadar" id="">

	<option value="Gaibandha Sadar-5700" select >Gaibandha Sadar-5700</option>
	
</select>

<select class="Gaibandha Bonarpara" id="">

	<option value="" select>Select a post </option>
	<option value="Bonarpara-5750">Bonarpara-5750</option>
	<option value="Saghata-5751">Saghata-5751</option>
	
</select>

<!--Kurigram-->

<select class="Kurigram Roumari" id="">

	<option value="Roumari-5640" select>Roumari-5640 </option>
	
</select>

<select class="Kurigram Rajibpur" id="">

	<option value="Rajibpur-5650" select>Rajibpur-5650</option>
	
</select>

<select class="Kurigram Nageshwar" id="">

	<option value="Nageshwar-5660" select>Nageshwar-5660</option>
	
</select>

<select class="Kurigram Bhurungamari" id="">

	<option value="Bhurungamari-5670" select>Bhurungamari-5670</option>
	
</select>

<select class="Kurigram Ulipur" id="">

	<option value="" select>Select a post </option>
	<option value="Ulipur-5620">Ulipur-5620</option>
	<option value="Bazarhat-5621">Bazarhat-5621</option>
	
</select>

<select class="Kurigram Rajarhat" id="">

	<option value="" select>Select a post </option>
	<option value="Rajarhat-5610">Rajarhat-5610</option>
	<option value="Nazimkhan-5611">Nazimkhan-5611</option>
	
</select>

<select class="Kurigram Sadar" id="">

	<option value="" select>Select a post </option>
	<option value="Phulbari-5680">Phulbari-5680</option>
	<option value="Pandul-5601">Pandul-5601</option>
	<option value="Kurigram Sadar-5600">Kurigram Sadar-5600</option>
	
</select>

<select class="Kurigram Chilmari" id="">

	<option value="" select>Select a post </option>
	<option value="Jorgachh-5631">Jorgachh-5631</option>
	<option value="Chilmari-5630">Chilmari-5630</option>
	
</select>

<!--Lalmonirhat-->

<select class="Lalmonirhat Tushbhandar" id="">

	<option value="Tushbhandar-5520" select>Tushbhandar-5520 </option>
	
</select>

<select class="Lalmonirhat Hatibandha" id="">

	<option value="Hatibandha-5530" select>Hatibandha-5530 </option>
	
</select>

<select class="Lalmonirhat Aditmari" id="">

	<option value="Aditmari-5510" select>Aditmari-5510</option>
	
</select>

<select class="Lalmonirhat Patgram" id="">

	<option value="" select>Select a post </option>
	<option value="Patgram-5540">Patgram-5540</option>
	<option value="Burimari-5542">Burimari-5542</option>
	<option value="Baura-5541">Baura-5541</option>
	
</select>

<select class="Lalmonirhat Sadar" id="">

	<option value="" select>Select a post </option>
	<option value="Moghalhat-5501">Moghalhat-5501</option>
	<option value="Lalmonirhat Sadar-5500">Lalmonirhat Sadar-5500</option>
	<option value="Kulaghat SO-5502">Kulaghat SO-5502</option>
	
</select>

<!--Nilphamari-->

<select class="Nilphamari Kishoriganj" id="">

	<option value="Kishoriganj-5320" select>Kishoriganj-5320</option>
	
</select>

<select class="Nilphamari Jaldhaka" id="">

	<option value="Jaldhaka-5330" select>Jaldhaka-5330</option>
	
</select>

<select class="Nilphamari Syedpur" id="">

	<option value="" select>Select a post </option>
	<option value="Syedpur Upashahar-5311">Syedpur Upashahar-5311</option>
	<option value="Syedpur-5310">Syedpur-5310</option>
	
</select>

<select class="Nilphamari Sadar" id="">

	<option value="" select>Select a post </option>
	<option value="Sugar Mil-5301">Sugar Mil-5301</option>
	<option value="Nilphamari Sadar-5300">Nilphamari Sadar-5300</option>
	
</select>

<select class="Nilphamari Domar" id="">

	<option value="" select>Select a post </option>
	<option value="Domar-5340">Domar-5340</option>
	<option value="Chilahati-5341">Chilahati-5341</option>
	
</select>

<select class="Nilphamari Domar" id="">

	<option value="" select>Select a post </option>
	<option value="Ghaga Kharibari-5351">Ghaga Kharibari-5351</option>
	<option value="Dimla-5350">Dimla-5350</option>
	
</select>

<!--Panchagarh-->

<select class="Panchagarh Tetulia" id="">

	<option value="Tetulia-5030" select>Tetulia-5030 </option>
	
</select>

<select class="Panchagar Sadar" id="">

	<option value="Panchagar Sadar-5000" select>Panchagar Sadar-5000</option>
	
</select>

<select class="Panchagar Boda" id="">

	<option value="Boda-5010" select>Boda-5010</option>
	
</select>

<select class="Panchagar Dabiganj" id="">

	<option value="Dabiganj-5020" select>Dabiganj-5020</option>
	
</select>

<select class="Panchagarh Domar" id="">

	<option value="" select>Select a post </option>
	<option value="Ghaga Kharibari-5351">Ghaga Kharibari-5351</option>
	<option value="Dimla-5350">Dimla-5350</option>
	
</select>

<select class="Panchagarh Chotto-Dab" id="">

	<option value="" select>Select a post </option>
	<option value="Mirjapur-5041">Mirjapur-5041</option>
	<option value="Chotto Dab-5040">Chotto Dab-5040</option>
	
</select>

<!--Rangpur-->

<select class="Rangpur Taraganj" id="">

	<option value="Taraganj-5420" select>Taraganj-5420</option>
	
</select>

<select class="Rangpur Pirgachha" id="">

	<option value="Pirgachha-5450" select>Pirgachha-5450</option>
	
</select>

<select class="Rangpur Mithapukur" id="">

	<option value="Mithapukur-5460" select>Mithapukur-5460</option>
	
</select>

<select class="Rangpur Gangachara" id="">

	<option value="Gangachara-5410" select>Gangachara-5410</option>
	
</select>


<select class="Rangpur Sadar" id="">

	<option value="" select>Select a post </option>
	<option value="Rangpur Upa-Shahar-5401">Rangpur Upa-Shahar-5401</option>
	<option value="Rangpur Sadar-5400">Rangpur Sadar-5400</option>
	<option value="Carmiecal Col-5405">Carmiecal Col-5405</option>
	<option value="Rangpur Cadet Colleg-5404"> Rangpur Cadet Colleg-5404</option>
	<option value="Mahiganj-5403">Mahiganj-5403</option>
	<option value="Alamnagar-5402">Alamnagar-5402</option>
	
</select>

<select class="Rangpur Kaunia" id="">

	<option value="" select>Select a post </option>
	<option value="Kaunia-5440">Kaunia-5440</option>
	<option value="Haragachh-5441">Haragachh-5441</option>
	
</select>

<select class="Rangpur Badarganj" id="">

	<option value="" select>Select a post </option>
	<option value="Shyampur-5431">Shyampur-5431</option>
	<option value="Badarganj-5430">Badarganj-5430</option>
	
</select>

<!--Thakurgaon-->

<select class="Thakurgaon Sadar" id="">

	<option value="" select>Select a post </option>
	<option value="Thakurgaon Sadar-5100">Thakurgaon Sadar-5100</option>
	<option value="Thakurgaon Road-5101">Thakurgaon Road-5101</option>
	<option value="Shibganj-5102">Shibganj-5102</option>
	<option value="Ruhia-5103">Ruhia-5103</option>
	
</select>

<select class="Thakurgaon Rani-Sankail" id="">

	<option value="" select>Select a post </option>
	<option value="Rani Sankail-5120">Rani Sankail-5120</option>
	<option value="Nekmarad-5121">Nekmarad-5121</option>
	
</select>

<select class="Thakurgaon Pirganj" id="">

	<option value="" select>Select a post </option>
	<option value="Pirganj-5470">Pirganj-5470</option>
	<option value="Pirganj-5110">Pirganj-5110</option>
	
</select>

<select class="Thakurgaon Jibanpur" id="">

	<option value="Jibanpur-5130" select>Jibanpur-5130 </option>
	
</select>


<select class="Thakurgaon Baliadangi" id="">

	<option value="" select>Select a post </option>
	<option value="Lahiri-5141">Lahiri-5141</option>
	<option value="Baliadangi-5140">Baliadangi-5140</option>
	
</select>

<!--Bogra-->

<select class="Bogra Sonatola" id="">

	<option value="Sonatola-5826" select>Sonatola-5826 </option>
	
</select>

<select class="Bogra Shibganj" id="">

	<option value="Shibganj-5810" select>Shibganj-5810 </option>
	
</select>

<select class="Bogra Nandigram" id="">

	<option value="Nandigram-5860" select>Nandigram-5860</option>
	
</select>

<select class="Bogra Kahalu" id="">

	<option value="Kahalu-5870" select>Kahalu-5870</option>
	
</select>


<select class="Bogra Sherpur" id="">

	<option value="" select>Select a post </option>
	<option value="Sherpur-5840">Sherpur-5840</option>
	<option value="Palli Unnyan Accadem-5842">Palli Unnyan Accadem-5842</option>
	<option value="Chandaikona-5841">Chandaikona-5841</option>
	
</select>

<select class="Bogra Sariakandi" id="">

	<option value="" select>Select a post </option>
	<option value="Sariakandi-5830">Sariakandi-5830</option>
	<option value="Chandan Baisha-5831">Chandan Baisha-5831</option>
	<option value="Chandaikona-5841">Chandaikona-5841</option>
	
</select>

<select class="Bogra Gabtoli" id="">

	<option value="" select>Select a post </option>
	<option value="Sukhanpukur-5821">Sukhanpukur-5821</option>
	<option value="Gabtoli-5820">Gabtoli-5820</option>
	
</select>

<select class="Bogra Dupchachia" id="">

	<option value="" select>Select a post </option>
	<option value="Talora-5881">Talora-5881</option>
	<option value="Dupchachia-5880">Dupchachia-5880</option>
	
</select>

<select class="Bogra Dhunat" id="">

	<option value="" select>Select a post </option>
	<option value="Gosaibari-5851">Gosaibari-5851</option>
	<option value="Dhunat-5850">Dhunat-5850</option>
	
</select>

<select class="Bogra Sadar" id="">

	<option value="" select>Select a post </option>
	<option value="Bogra Sadar-5800">Bogra Sadar-5800</option>
	<option value="Bogra Canttonment-5801">Bogra Canttonment-5801</option>
	
</select>

<select class="Bogra Adamdighi" id="">

	<option value="" select>Select a post </option>
	<option value="Santahar-5891">Santahar-5891</option>
	<option value="Nasharatpur-5892">Nasharatpur-5892</option>
	<option value="Adamdighi-5890">Adamdighi-5890</option>
	
</select>

<!--Chapinawabganj-->

<select class="Chapinawabganj Sadar" id="">

	<option value="" select>Select a post </option>
	<option value="Ramchandrapur-6302">Ramchandrapur-6302</option>
	<option value="Rajarampur-6301">Rajarampur-6301</option>
	<option value="Chapinawbganj Sadar-630">Chapinawbganj Sadar-630</option>
	<option value="Amnura-6303">Amnura-6303</option>
	
</select>

<select class="Chapinawabganj Bholahat" id="">

	<option value="Bholahat-6330" select>Bholahat-6330</option>
	
</select>

<select class="Chapinawabganj Shibganj-U.P.O" id="">

	<option value="" select>Select a post </option>
	<option value="Shibganj U.P.O-6340">Shibganj U.P.O-6340</option>
	<option value="Manaksha-6342">Manaksha-6342</option>
	<option value="Kansart-6341">Kansart-6341</option>
	
</select>

<select class="Chapinawabganj Rohanpur" id="">

	<option value="" select>Select a post </option>
	<option value="Rohanpur-6320">Rohanpur-6320</option>
	<option value="Gomashtapur-6321">Gomashtapur-63212</option>
	
</select>

<select class="Chapinawabganj Nachol" id="">

	<option value="" select>Select a post </option>
	<option value="Nachol-6310">Nachol-6310</option>
	<option value="Mandumala-6311">Mandumala-6311</option>
	
</select>



<!--Joypurhat-->

<select class="Joypurhat Panchbibi" id="">

	<option value="Panchbibi-5910" select>Panchbibi-5910 </option>
	
</select>

<select class="Joypurhat Khetlal" id="">

	<option value="Khetlal-5920" select>Khetlal-5920</option>
	
</select>

<select class="Joypurhat kalai" id="">

	<option value="kalai-5930" select>kalai-5930</option>
	
</select>

<select class=" Joypurhat Sadar" id="">

	<option value="Joypurhat Sadar-5900" select>Joypurhat Sadar-5900</option>
	
</select>

<select class="Joypurhat Akklepur" id="">

	<option value="" select>Select a post </option>
	<option value="Tilakpur-5942">Tilakpur-5942</option>
	<option value="Jamalganj-5941">Jamalganj-5941</option>
	<option value="Akklepur-5940">Akklepur-5940</option>
	
</select>

<!--Naogaon-->

<select class="Naogaon Sapahar" id="">

	<option value="" select>Select a post </option>
	<option value="Sapahar-6560">Sapahar-6560</option>
	<option value="Moduhil-6561">Moduhil-6561</option>
	
</select>

<select class="Naogaon Raninagar" id="">

	<option value="" select>Select a post </option>
	<option value="Raninagar-6590">Raninagar-6590</option>
	<option value="Kashimpur-6591">Kashimpur-6591</option>
	
</select>

<select class="Naogaon Prasadpur" id="">

	<option value="" select>Select a post </option>
	<option value="Prasadpur-6510">Prasadpur-6510</option>
	<option value="Manda-6511">Manda-6511</option>
	<option value="Balihar-6512">Balihar-6512</option>
	
</select>

<select class="Naogaon Patnitala" id="">

	<option value="Patnitala-6540" select>Patnitala-6540 </option>
	
</select>

<select class="Naogaon Niamatpur" id="">

	<option value="Niamatpur-6520" select>Niamatpur-6520 </option>
	
</select>

<select class="Naogaon Sadar" id="">

	<option value="Naogaon Sadar-6500" select>Naogaon Sadar-6500</option>
	
</select>

<select class="Naogaon Mahadebpur" id="">

	<option value="Mahadebpur-6530" select>Mahadebpur-6530</option>
	
</select>

<select class="Naogaon Dhamuirhat" id="">

	<option value="Dhamuirhat-6580" select>Dhamuirhat-6580</option>
	
</select>

<select class="Naogaon Badalgachhi" id="">

	<option value="Badalgachhi-6570" select>Badalgachhi-6570</option>
	
</select>

<select class="Naogaon Nitpur" id="">

	<option value="" select>Select a post </option>
	<option value="Porsa-6551">Porsa-6551</option>
	<option value="Panguria-6552">Panguria-6552</option>
	<option value="Nitpur-6550">Nitpur-6550</option>
	
</select>

<select class="Naogaon Ahsanganj" id="">

	<option value="" select>Select a post </option>
	<option value="Bandai-6597">Bandai-6597</option>
	<option value="Ahsanganj-6596">Ahsanganj-6596</option>
	
</select>

<!--Natore-->

<select class="Natore Singra" id="">

	<option value="Singra-6450" select>Singra-6450 </option>
	
</select>

<select class="Natore Laxman" id="">

	<option value="Laxman-6410" select>Laxman-6410</option>
	
</select>

<select class="Natore Hatgurudaspur" id="">

	<option value="Hatgurudaspur-6440" select>Hatgurudaspur-6440</option>
	
</select>

<select class="Natore Sadar" id="">

	<option value="" select>Select a post </option>
	<option value="Natore Sadar-6400">Natore Sadar-6400</option>
	<option value="Madhnagar-6403">Madhnagar-6403</option>
	<option value="Digapatia-6401">Digapatia-6401</option>
	<option value="Baiddyabal Gharia-6402">Baiddyabal Gharia-6402</option>
	
</select>

<select class="Natore Harua" id="">

	<option value="" select>Select a post </option>
	<option value="Harua-6430">Harua-6430</option>
	<option value="Dayarampur-6431">Dayarampur-6431</option>
	<option value="Baraigram-6432">Baraigram-6432</option>
	
</select>

<select class="Natore Gopalpur-U.P.O" id="">

	<option value="" select>Select a post </option>
	<option value="Lalpur S.O-6421">Lalpur S.O-6421</option>
	<option value="Gopalpur U.P.O-6420">Gopalpur U.P.O-6420</option>
	<option value="Abdulpur-6422">Abdulpur-6422</option>
	
</select>



























