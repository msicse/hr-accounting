<select class="Bagerhat"   >
	<option value="">select</option>

	<option value="Sadar">Bagerhat Sadar</option>

	<option value="Chalna-Ankorage">Chalna Ankorage</option>

	<option value="Chitalmari">Chitalmari</option>

	<option value="Fakirhat">Fakirhat</option>

	<option value="Kachua-UPO">Kachua UPO</option>

	<option value="Mollahat">Mollahat</option>

	<option value="Morelganj">Morelganj</option>

	<option value="Rampal">Rampal</option>

	<option value="Rayenda">Rayenda</option>
</select>
<select class="Chuadanga"  >
	<option value="">Select</option>
	<option value="Alamdanga" >Alamdanga</option>

	<option value="Sadar">Chuadanga Sadar</option>

	<option value="Damurhuda">Damurhuda</option>

	<option value="Doulatganj">Doulatganj</option>
</select>

<select class="Jessore"  >
	<option value="" selected>Select a Thana</option>

	<option value="Bagharpara">Bagharpara</option>

	<option value="Chaugachha">Chaugachha</option>

	<option value="Chougachha">Chougachha</option>

	<option value="Sadar">Jessore Sadar</option>

	<option value="Jhikargachha">Jhikargachha</option>

	<option value="Keshabpur">Keshabpur</option>

	<option value="Keshobpur">Keshobpur</option>

	<option value="Monirampur">Monirampur</option>

	<option value="Noapara">Noapara</option>

	<option value="Sarsa">Sarsa</option>

</select>

<select class="Jinaidaha"   >
	<option value="" selected>Select a Thana</option>

	<option value="Harinakundu">Harinakundu</option>

	<option value="Sadar">Jinaidaha Sadar</option>

	<option value="Kotchandpur">Kotchandpur</option>

	<option value="Maheshpur">Maheshpur</option>

	<option value="Mahespur">Mahespur</option>

	<option value="Naldanga">Naldanga</option>

	<option value="Shailakupa">Shailakupa</option>
</select>

<!--- Khulna-->

<select class="Khulna" id=""  >
	<option value="" selected>Select a Thana</option>

	<option value="Alaipur">Alaipur</option>

	<option value="Batiaghat">Batiaghat</option>

	<option value="Chalna-Bazar">Chalna Bazar</option>

	<option value="Digalia">Digalia</option>

	<option value="Sadar">Khulna Sadar</option>

	<option value="Madinabad">Madinabad</option>

	<option value="Paikgachha">Paikgachha</option>

	<option value="Phultala">Phultala</option>

	<option value="Sajiara">Sajiara</option>

	<option value="Terakhada">Terakhada</option>

</select>

<!--Kustia-->
<select class="Kustia" id=""  >
	<option value="" selected>Select a Thana</option>

	<option value="Bheramara">Bheramara</option>

	<option value="Janipur">Janipur</option>

	<option value="Kumarkhali">Kumarkhali</option>

	<option value="Sadar">Kustia Sadar</option>

	<option value="Mirpur">Mirpur</option>

	<option value="Rafayetpur">Rafayetpur</option>

</select>

<select class="Bandarban"  >
	<option value="Alikadam">Alikadam</option>

	<option value="Sadar">Bandarban Sadar</option>

	<option value="Naikhong">Naikhong</option>

	<option value="Roanchhari">Roanchhari</option>

	<option value="Ruma">Ruma</option>

	<option value="Thanchi">Thanchi</option>
</select>
<!--Magura-->

<select class="Magura" id=""  >

	<option value="" selected>Select a Thana</option>

	<option value="Arpara">Arpara</option>

	<option value="Sadar">Magura Sadar</option>

	<option value="Mohammadpur">Mohammadpur</option>

	<option value="Shripur">Shripur</option>

</select>
<!--Meherpur-->
<select class="Meherpur" id=""  >

	<option value="" selected>Select a Thana</option>

	<option value="Gangni">Gangni</option>

	<option value="Sadar">Meherpur Sadar</option>

</select>

<!--Narail-->
<select class="Narail" id=""  >

	<option value="" selected>Select a Thana</option>

	<option value="Kalia">Kalia</option>

	<option value="Laxmipasha">Laxmipasha</option>

	<option value="Mohajan">Mohajan</option>

	<option value="Sadar">Narail Sadar</option>

</select>
<!--Satkhira-->

<select class="Satkhira" id=""  >

	<option value="" selected>Select a Thana</option>

	<option value="Ashashuni">Ashashuni</option>

	<option value="Debbhata">Debbhata</option>

	<option value="Kalaroa">Kalaroa</option>

	<option value="Kaliganj">Kaliganj UPO</option>

	<option value="Nakipur">Nakipur</option>

	<option value="Sadar">Satkhira Sadar</option>

	<option value="Taala">Taala</option>

</select>
<!--Dhaka-->


<select class="Dhaka" id=""  >

	<option value="" selected>Select a Thana</option>

	<option value="Demra">Demra</option>

	<option value="Cantt">Dhaka Cantt.</option>

	<option value="GPO">Dhaka GPO</option>

	<option value="Sadar">Dhaka Sadar</option>

	<option value="Sadar1">Dhaka Sadar</option>

	<option value="Dhamrai">Dhamrai</option>

	<option value="Dhanmondi">Dhanmondi</option>

	<option value="Gulshan">Gulshan</option>

	<option value="Jatrabari">Jatrabari</option>

	<option value="Joypara">Joypara</option>

	<option value="Keraniganj">Keraniganj</option>

	<option value="Khilgaon">Khilgaon</option>

	<option value="Khilkhet">Khilkhet</option>

	<option value="Lalbag">Lalbag</option>

	<option value="Mirpur">Mirpur</option>

	<option value="Mohammadpur">Mohammadpur</option>

	<option value="Motijheel">Motijheel</option>

	<option value="Nawabganj">Nawabganj</option>

	<option value="New-market">New market</option>

	<option value="Palton">Palton</option>

	<option value="Ramna">Ramna</option>

	<option value="Sabujbag">Sabujbag</option>

	<option value="Savar">Savar</option>

	<option value="Sutrapur">Sutrapur</option>

	<option value="Tejgaon">Tejgaon</option>

	<option value="Tejgaon-Industrial-Area">Tejgaon Industrial Area</option>

	<option value="Uttara">Uttara</option>

</select>
<!--Faridpur-->

<select class="Faridpur" id="">
	
	<option value="" selected>Select a Thana</option>

	<option value="Alfadanga">Alfadanga</option>

	<option value="Bhanga">Bhanga</option>

	<option value="Boalmari">Boalmari</option>

	<option value="Charbhadrasan">Charbhadrasan</option>

	<option value="Sadar">Faridpur Sadar</option>

	<option value="Madukhali">Madukhali</option>

	<option value="Nagarkanda">Nagarkanda</option>

	<option value="Sadarpur">Sadarpur</option>

	<option value="Shriangan">Shriangan</option>
	
</select>

<!--Gazipur-->

<select class="Gazipur" id="">

	<option value="" selected>Select a Thana</option>

	<option value="Sadar">Gazipur Sadar</option>

	<option value="Kaliakaar">Kaliakaar</option>

	<option value="Kaliganj">Kaliganj</option>

	<option value="Kapashia">Kapashia</option>

	<option value="Kapasia">Kapasia</option>

	<option value="Monnunagar">Monnunagar</option>

	<option value="Monnunagar">Sreepur</option>

	<option value="Sripur">Sripur</option>


</select>

<!--Gopalganj-->

<select class="Gopalganj" id="">

	<option value="" selected>Select a Thana</option>

	<option value="Sadar">Gopalganj Sadar</option>

	<option value="Kashiani">Kashiani</option>

	<option value="Kotalipara">Kotalipara</option>

	<option value="Maksudpur">Maksudpur</option>

	<option value="Tungipara">Tungipara</option>


</select>

<!--Jamalpur-->

<select class="Jamalpur" id="">

	<option value="" selected>Select a Thana</option>

	<option value="Dewangonj">Dewangonj</option>

	<option value="Islampur">Islampur</option>

	<option value="Jamalpur">Jamalpur</option>

	<option value="Malandah">Malandah</option>

	<option value="Mathargonj">Mathargonj</option>

	<option value="Shorishabari">Shorishabari</option>


</select>

<!--Kishoreganj-->

<select class="Kishoreganj" id="">

	<option value="" selected>Select a Thana</option>

	<option value="Bajitpur">Bajitpur</option>

	<option value="Bhairob">Bhairob</option>

	<option value="Hossenpur">Hossenpur</option>

	<option value="Itna">Itna</option>

	<option value="Karimganj">Karimganj</option>

	<option value="Katiadi">Katiadi</option>

	<option value="Sadar">Kishoreganj Sadar</option>

	<option value="Kuliarchar">Kuliarchar</option>

	<option value="Mithamoin">Mithamoin</option>

	<option value="Nikli">Nikli</option>

	<option value="Ostagram">Ostagram</option>

	<option value="Pakundia">Pakundia</option>

	<option value="Tarial">Tarial</option>


</select>

<!--Madaripur-->

<select class="Madaripur" id="">

	<option value="" selected>Select a Thana</option>

	<option value="Barhamganj">Barhamganj</option>

	<option value="kalkini">kalkini</option>

	<option value="Sadar">Madaripur Sadar</option>

	<option value="Rajoir">Rajoir</option>


</select>


<!--Manikganj-->

<select class="Manikganj" id="">

	<option value="" selected>Select a Thana</option>

	<option value="Doulatpur">Doulatpur</option>

	<option value="Gheor">Gheor</option>

	<option value="Lechhraganj">Lechhraganj</option>

	<option value="Sadar">Manikganj Sadar</option>

	<option value="Saturia">Saturia</option>

	<option value="Shibloya">Shibloya</option>

	<option value="Singari">Singari</option>


</select>

<!--Munshiganj-->

<select class="Munshiganj" id="">

	<option value="" selected>Select a Thana</option>

	<option value="13">Gajaria</option>

	<option value="15">Lohajong</option>

	<option value="407">Munshiganj Sadar</option>

	<option value="16">Sirajdikhan</option>

	<option value="17">Srinagar</option>

	<option value="14">Tangibari</option>


</select>

<!--Mymensingh-->

<select class="Mymensingh" id="">

	<option value="" selected>Select a Thana</option>

	<option value="Bhaluka">Bhaluka</option>

	<option value="Fulbaria">Fulbaria</option>

	<option value="Gaforgaon">Gaforgaon</option>

	<option value="Gouripur">Gouripur</option>

	<option value="Haluaghat">Haluaghat</option>

	<option value="Isshwargonj">Isshwargonj</option>

	<option value="Muktagachha">Muktagachha</option>

	<option value="Sadar">Mymensingh Sadar</option>

	<option value="Nandail">Nandail</option>

	<option value="Phulpur">Phulpur</option>

	<option value="Trishal">Trishal</option>


</select>


<!--Narayanganj-->

<select class="Narayanganj" id="">

	<option value="" selected>Select a Thana</option>

	<option value="Araihazar">Araihazar</option>

	<option value="Baidder-Bazar">Baidder Bazar</option>

	<option value="Bandar">Bandar</option>

	<option value="Fatullah">Fatullah</option>

	<option value="Sadar">Narayanganj Sadar</option>

	<option value="Rupganj">Rupganj</option>

	<option value="Siddirganj">Siddirganj</option>



</select>

<!--Narshingdi-->

<select class="Narshingdi" id="">

	<option value="" selected>Select a Thana</option>

	<option value="Belabo">Belabo</option>

	<option value="Monohordi">Monohordi</option>

	<option value="Sadar">Narshingdi Sadar</option>

	<option value="Palash">Palash</option>

	<option value="Raypura">Raypura</option>

	<option value="Shibpur">Shibpur</option>



</select>

<!--Netrakona-->

<select class="Netrakona" id="">

	<option value="" selected>Select a Thana</option>

	<option value="Susung-Durgapur"> Susung Durgapur</option>

	<option value="Atpara">Atpara</option>

	<option value="Barhatta">Barhatta</option>

	<option value="Dharmapasha">Dharmapasha</option>

	<option value="Dhobaura">Dhobaura</option>

	<option value="Kalmakanda">Kalmakanda</option>

	<option value="Kendua">Kendua</option>

	<option value="Khaliajuri">Khaliajuri</option>

	<option value="Madan">Madan</option>

	<option value="Moddhynagar">Moddhynagar</option>

	<option value="Mohanganj">Mohanganj</option>

	<option value="Sadar">Netrakona Sadar</option>

	<option value="Purbadhola">Purbadhola</option>

</select>


<!--Rajbari-->

<select class="Rajbari" id="">

	<option value="" selected>Select a Thana</option>

	<option value="Baliakandi">Baliakandi</option>

	<option value="Pangsha">Pangsha</option>

	<option value="Sadar">Rajbari Sadar</option>

</select>


<!--Shariatpur-->

<select class="Shariatpur" id="">

	<option value="" selected>Select a Thana</option>

	<option value="Bhedorganj">Bhedorganj</option>

	<option value="Damudhya">Damudhya</option>

	<option value="Gosairhat">Gosairhat</option>

	<option value="Jajira">Jajira</option>

	<option value="Naria">Naria</option>

	<option value="Sadar">Shariatpur Sadar</option>

</select>

<!--Sherpur-->

<select class="Sherpur" id="">

	<option value="" selected>Select a Thana</option>

	<option value="Bakshigonj">Bakshigonj</option>

	<option value="Jhinaigati">Jhinaigati</option>

	<option value="Nakla">Nakla</option>

	<option value="Nalitabari">Nalitabari</option>

	<option value="Shadar">Sherpur Shadar</option>

	<option value="Shribardi">Shribardi</option>

</select>

<!--Tangail-->

<select class="Tangail" id="">

	<option value="" selected>Select a Thana</option>

	<option value="Basail">Basail</option>

	<option value="Bhuapur">Bhuapur</option>

	<option value="Delduar">Delduar</option>

	<option value="Ghatail">Ghatail</option>

	<option value="Gopalpur">Gopalpur</option>

	<option value="Kalihati">Kalihati</option>

	<option value="Kashkaolia">Kashkaolia</option>

	<option value="Khas-Kowlia">Khas Kowlia</option>

	<option value="Madhupur">Madhupur</option>

	<option value="Mirzapur">Mirzapur</option>

	<option value="Nagarpur">Nagarpur</option>

	<option value="Sakhipur">Sakhipur</option>

	<option value="Sadar">Tangail Sadar</option>

</select>

<!--Bandarban-->

<select class="Bandarban" id="">

	<option value="" selected>Select a Thana</option>
	
	<option value="Alikadam">Alikadam</option>

	<option value="Sadar">Bandarban Sadar</option>

	<option value="Naikhong">Naikhong</option>

	<option value="Roanchhari">Roanchhari</option>

	<option value="Ruma">Ruma</option>

	<option value="Thanchi">Thanchi</option>


</select>

<!--Brahmanbaria-->

<select class="Brahmanbaria" id="">

	<option value="" selected>Select a Thana</option>

	<option value="Akhaura">Akhaura</option>

	<option value="Banchharampur">Banchharampur</option>

	<option value="Sadar">Brahamanbaria Sadar</option>

	<option value="Kasba">Kasba</option>

	<option value="Nabinagar">Nabinagar</option>

	<option value="Nasirnagar">Nasirnagar</option>

	<option value="Sarail">Sarail</option>

</select>

<!--Chandpur-->

<select class="Chandpur" id="">

	<option value="" selected>Select a Thana</option>
	
	<option value="Sadar">Chandpur Sadar</option>

	<option value="Faridganj">Faridganj</option>

	<option value="Hajiganj">Hajiganj</option>

	<option value="Hayemchar">Hayemchar</option>

	<option value="Kachua">Kachua</option>

	<option value="Matlobganj">Matlobganj</option>

	<option value="Shahrasti">Shahrasti</option>

</select>

<!--Chittagong-->

<select class="Chittagong" id="">

	<option value="" selected>Select a Thana</option>

	<option value="Anawara">Anawara</option>

	<option value="Boalkhali">Boalkhali</option>

	<option value="Sadar">Chittagong Sadar</option>

	<option value="East-Joara">East Joara</option>

	<option value="Fatikchhari">Fatikchhari</option>

	<option value="Hathazari">Hathazari</option>

	<option value="Jaldi">Jaldi</option>

	<option value="Lohagara">Lohagara</option>

	<option value="Mirsharai">Mirsharai</option>

	<option value="Patiya">Patiya</option>

	<option value="Rangunia">Rangunia</option>

	<option value="Rouzan">Rouzan</option>

	<option value="Sandwip">Sandwip</option>

	<option value="Satkania">Satkania</option>

	<option value="Sitakunda">Sitakunda</option>


</select>

<!--Comilla-->

<select class="Comilla" id="">

	<option value="" selected>Select a Thana</option>

	<option value="Barura">Barura</option>

	<option value="Brahmanpara">Brahmanpara</option>

	<option value="Burichang">Burichang</option>

	<option value="Chandina">Chandina</option>

	<option value="Chouddagram">Chouddagram</option>

	<option value="Sadar">Comilla Sadar</option>

	<option value="Daudkandi">Daudkandi</option>

	<option value="Davidhar">Davidhar</option>

	<option value="Homna">Homna</option>

	<option value="Laksam">Laksam</option>

	<option value="Langalkot">Langalkot</option>

	<option value="Muradnagar">Muradnagar</option>


</select>

<!--Cox’s Bazar-->

<select class="Coxs-Bazar" id="">

	<option value="" selected>Select a Thana</option>

	<option value="Chiringga">Chiringga</option>

	<option value="Sadar">Coxs Bazar Sadar</option>

	<option value="Gorakghat">Gorakghat</option>

	<option value="Kutubdia">Kutubdia</option>

	<option value="Ramu">Ramu</option>

	<option value="Teknaf">Teknaf</option>

	<option value="Ukhia">Ukhia</option>


</select>

<!--Feni-->

<select class="Feni" id="">

	<option value="" selected>Select a Thana</option>

	<option value="Chhagalnaia">Chhagalnaia</option>

	<option value="Dagonbhuia">Dagonbhuia</option>

	<option value="Sadar">Feni Sadar</option>

	<option value="Pashurampur">Pashurampur</option>

	<option value="Sonagazi">Sonagazi</option>


</select>

<!--Khagrachari-->

<select class="Khagrachari" id="">

	<option value="" selected>Select a Thana</option>

	<option value="Diginala">Diginala</option>

	<option value="Sadar">Khagrachari Sadar</option>

	<option value="Laxmichhari">Laxmichhari</option>

	<option value="Mahalchhari">Mahalchhari</option>

	<option value="Manikchhari">Manikchhari</option>

	<option value="Matiranga">Matiranga</option>

	<option value="Panchhari">Panchhari</option>

	<option value="Ramghar-Head-Office">Ramghar Head Office</option>

</select>

<!--Lakshmipur-->

<select class="Lakshmipur" id="">

	<option value="" selected>Select a Thana</option>


	<option value="Char-Alexgander">Char Alexgander</option>

	<option value="Sadar">Lakshimpur Sadar</option>

	<option value="Ramganj">Ramganj</option>

	<option value="Raypur">Raypur</option>

</select>

<!--Noakhali-->

<select class="Noakhali" id="">

	<option value="" selected>Select a Thana</option>


	<option value="Basurhat">Basurhat</option>

	<option value="Begumganj">Begumganj</option>

	<option value="Chatkhil">Chatkhil</option>

	<option value="Hatiya">Hatiya</option>

	<option value="Sadar">Noakhali Sadar</option>

	<option value="Senbag">Senbag</option>

</select>

<!--Rangamati-->

<select class="Rangamati" id="">

	<option value="" selected>Select a Thana</option>


	<option value="Barakal">Barakal</option>

	<option value="Bilaichhari">Bilaichhari</option>

	<option value="Jarachhari">Jarachhari</option>

	<option value="Kalampati">Kalampati</option>

	<option value="Kaptai">Kaptai</option>

	<option value="Longachh">Longachh</option>

	<option value="Marishya">Marishya</option>

	<option value="Naniachhar">Naniachhar</option>

	<option value="Rajsthali">Rajsthali</option>

	<option value="Sadar">Rangamati Sadar</option>

</select>

<!--Hobiganj-->

<select class="Hobiganj" id="">

	<option value="" selected>Select a Thana</option>


	<option value="Azmireeganj">Azmireeganj</option>

	<option value="Bahubal">Bahubal</option>

	<option value="Baniachang">Baniachang</option>

	<option value="Chunarughat">Chunarughat</option>

	<option value="Sadar">Hobiganj Sadar</option>

	<option value="Kalauk">Kalauk</option>

	<option value="Madhabpur">Madhabpur</option>

	<option value="Nabiganj">Nabiganj</option>

</select>

<!--Moulvibazar-->

<select class="Moulvibazar" id="">

	<option value="" selected>Select a Thana</option>


	<option value="Baralekha">Baralekha</option>

	<option value="Kamalganj">Kamalganj</option>

	<option value="Kulaura">Kulaura</option>

	<option value="Sadar">Moulvibazar Sadar</option>

	<option value="Rajnagar">Rajnagar</option>

	<option value="Srimangal">Srimangal</option>

</select>


<!--Sunamganj-->

<select class="Sunamganj" id="">

	<option value="" selected>Select a Thana</option>

	<option value="Bishamsarpur">Bishamsarpur</option>

	<option value="Chhatak">Chhatak</option>

	<option value="Dhirai-Chandpur">Dhirai Chandpur</option>

	<option value="Duara-bazar">Duara bazar</option>

	<option value="Ghungiar">Ghungiar</option>

	<option value="Jagnnathpur">Jagnnathpur</option>

	<option value="Sachna">Sachna</option>

	<option value="Sadar">Sunamganj Sadar</option>

	<option value="Tahirpur">Tahirpur</option>

</select>

<!--Sylhet-->

<select class="Sylhet" id="">

	<option value="" selected>Select a Thana</option>

	<option value="Balaganj">Balaganj</option>

	<option value="Bianibazar">Bianibazar</option>

	<option value="Bishwanath">Bishwanath</option>

	<option value="Fenchuganj">Fenchuganj</option>

	<option value="Goainhat">Goainhat</option>

	<option value="Gopalganj">Gopalganj</option>

	<option value="Jaflong">Jaflong</option>

	<option value="Jaintapur">Jaintapur</option>

	<option value="Jakiganj">Jakiganj</option>

	<option value="Kanaighat">Kanaighat</option>

	<option value="Kompanyganj">Kompanyganj</option>

	<option value="Sadar">Sylhet Sadar</option>


</select>

<!--Barguna-->

<select class="Barguna" id="">

	<option value="" selected>Select a Thana</option>
	
	<option value="Amtali">Amtali</option>

	<option value="Bamna">Bamna</option>

	<option value="Sadar">Barguna Sadar</option>

	<option value="Betagi">Betagi</option>

	<option value="Patharghata">Patharghata</option>

</select>

<!--Barishal-->

<select class="Barishal" id="">

	<option value="" selected>Select a Thana</option>

	<option value="Agailzhara">Agailzhara</option>

	<option value="Babuganj">Babuganj</option>

	<option value="Barajalia">Barajalia</option>

	<option value="Sadar">Barishal Sadar</option>

	<option value="Gouranadi">Gouranadi</option>

	<option value="Mahendiganj">Mahendiganj</option>

	<option value="Muladi">Muladi</option>

	<option value="Sahebganj">Sahebganj</option>

	<option value="Uzirpur">Uzirpur</option>

</select>

<!--Bhola-->

<select class="Bhola" id="">

	<option value="" selected>Select a Thana</option>
	
	<option value="Sadar">Bhola Sadar</option>

	<option value="Borhanuddin-UPO">Borhanuddin UPO</option>

	<option value="Charfashion">Charfashion</option>

	<option value="Doulatkhan">Doulatkhan</option>

	<option value="Hajirhat">Hajirhat</option>

	<option value="Hatshoshiganj">Hatshoshiganj</option>

	<option value="Lalmohan-UPO">Lalmohan UPO</option>


</select>

<!--Jhalokathi-->

<select class="Jhalokathi" id="">

	<option value="" selected>Select a Thana</option>

	<option value="Sadar">Jhalokathi Sadar</option>

	<option value="Kathalia">Kathalia</option>

	<option value="Nalchhiti">Nalchhiti</option>

	<option value="Rajapur">Rajapur</option>


</select>

<!--Patuakhali-->

<select class="Patuakhali" id="">

	<option value="" selected>Select a Thana</option>

	<option value="Bauphal">Bauphal</option>

	<option value="Dashmina">Dashmina</option>

	<option value="Galachipa">Galachipa</option>

	<option value="Khepupara">Khepupara</option>

	<option value="Sadar">Patuakhali Sadar</option>

	<option value="Subidkhali">Subidkhali</option>


</select>

<!--Pirojpur-->

<select class="Pirojpur" id="">

	<option value="" selected>Select a Thana</option>

	<option value="Bauphal">Bauphal</option>

	<option value="Dashmina">Dashmina</option>

	<option value="Galachipa">Galachipa</option>

	<option value="Khepupara">Khepupara</option>

	<option value="Sadar">Patuakhali Sadar</option>

	<option value="Subidkhali">Subidkhali</option>


</select>

<!--Dinajpur-->

<select class="Dinajpur" id="">

	<option value="" selected>Select a Thana</option>

	<option value="Bangla-Hili">Bangla Hili</option>

	<option value="Biral">Biral</option>

	<option value="Birampur">Birampur</option>

	<option value="Birganj">Birganj</option>

	<option value="Chrirbandar">Chrirbandar</option>

	<option value="Sadar">Dinajpur Sadar</option>

	<option value="Khansama">Khansama</option>

	<option value="Maharajganj">Maharajganj</option>

	<option value="Nababganj">Nababganj</option>

	<option value="Osmanpur">Osmanpur</option>

	<option value="Parbatipur">Parbatipur</option>

	<option value="Phulbari">Phulbari</option>

	<option value="Setabganj">Setabganj</option>


</select>

<!--Gaibandha-->

<select class="Gaibandha" id="">

	<option value="" selected>Select a Thana</option>

	<option value="Bonarpara">Bonarpara</option>

	<option value="Sadar">Gaibandha Sadar</option>

	<option value="Gobindaganj">Gobindaganj</option>

	<option value="Palashbari">Palashbari</option>

	<option value="Phulchhari">Phulchhari</option>

	<option value="Saadullapur">Saadullapur</option>

	<option value="Sundarganj">Sundarganj</option>

</select>

<!--Kurigram-->

<select class="Kurigram" id="">

	<option value="" selected>Select a Thana</option>

	<option value="Bhurungamari">Bhurungamari</option>

	<option value="Chilmari">Chilmari</option>

	<option value="Sadar">Kurigram Sadar</option>

	<option value="Nagashwar">Nagashwar</option>

	<option value="Nageshwar">Nageshwar</option>

	<option value="Rajarhat">Rajarhat</option>

	<option value="Rajibpur">Rajibpur</option>

	<option value="Roumari">Roumari</option>

	<option value="Ulipur">Ulipur</option>
	
</select>

<!--Lalmonirhat-->

<select class="Lalmonirhat" id="">

	<option value="" selected>Select a Thana</option>

	<option value="Bhurungamari">Bhurungamari</option>

	<option value="Chilmari">Chilmari</option>

	<option value="Sadar">Kurigram Sadar</option>

	<option value="Nagashwar">Nagashwar</option>

	<option value="Nageshwar">Nageshwar</option>

	<option value="Rajarhat">Rajarhat</option>

	<option value="Rajibpur">Rajibpur</option>

	<option value="Roumari">Roumari</option>

	<option value="Ulipur">Ulipur</option>
	
</select>

<!--Nilphamari-->

<select class="Nilphamari" id="">

	<option value="" selected>Select a Thana</option>

	<option value="Dimla">Dimla</option>

	<option value="Domar">Domar</option>

	<option value="Jaldhaka">Jaldhaka</option>

	<option value="Kishoriganj">Kishoriganj</option>

	<option value="Sadar">Nilphamari Sadar</option>

	<option value="Nilphamari-Sugar-Mil">Nilphamari Sugar Mil</option>

	<option value="Syedpur">Syedpur</option>

</select>

<!--Panchagarh-->

<select class="Panchagarh" id="">

	<option value="" selected>Select a Thana</option>

	<option value="Boda">Boda</option>

	<option value="Chotto-Dab">Chotto Dab</option>

	<option value="Dabiganj">Dabiganj</option>

	<option value="Sadar">Panchagra Sadar</option>

	<option value="Tetulia">Tetulia</option>

</select>

<!--Rangpur-->

<select class="Rangpur" id="">

	<option value="" selected>Select a Thana</option>

	<option value="Badarganj">Badarganj</option>

	<option value="Gangachara">Gangachara</option>

	<option value="Kaunia">Kaunia</option>

	<option value="Mithapukur">Mithapukur</option>

	<option value="Pirgachha">Pirgachha</option>

	<option value="Pirganj">Pirganj</option>

	<option value="Sadar">Rangpur Sadar</option>

	<option value="Taraganj">Taraganj</option>

</select>

<!--Thakurgaon-->

<select class="Thakurgaon" id="">

	<option value="" selected>Select a Thana</option>


	<option value="Baliadangi">Baliadangi</option>

	<option value="Jibanpur">Jibanpur</option>

	<option value="Pirganj">Pirganj</option>

	<option value="Rani-Sankail">Rani Sankail</option>

	<option value="Sadar">Thakurgaon Sadar</option>

</select>

<!--Bogra-->

<select class="Bogra" id="">

	<option value="Alamdighi">Alamdighi</option>

	<option value="Sadar">Bogra Sadar</option>

	<option value="Dhunat">Dhunat</option>

	<option value="Dupchachia">Dupchachia</option>

	<option value="Gabtoli">Gabtoli</option>

	<option value="Kahalu">Kahalu</option>

	<option value="Majhira">Majhira</option>

	<option value="Nandigram">Nandigram</option>

	<option value="Sariakandi">Sariakandi</option>

	<option value="Sherpur">Sherpur</option>

	<option value="Shibganj">Shibganj</option>

	<option value="Sonatola">Sonatola</option>

</select>


<!--Chapinawabganj-->

<select class="Chapinawabganj" id="">

	<option value="" selected>Select a Thana</option>

	<option value="Bholahat">Bholahat</option>

	<option value="Sadar">Chapinawabganj Sadar</option>

	<option value="Nachol">Nachol</option>

	<option value="Rohanpur">Rohanpur</option>

	<option value="Shibganj-U.P.O">Shibganj U.P.O</option>

</select>

<!--Joypurhat-->

<select class="Joypurhat" id="">

	<option value="" selected>Select a Thana</option>

	<option value="Akkelpur">Akkelpur</option>

	<option value="Sadar">Joypurhat Sadar</option>

	<option value="kalai">kalai</option>

	<option value="Khetlal">Khetlal</option>

	<option value="Panchbibi">Panchbibi</option>

</select>

<!--Naogaon-->

<select class="Naogaon" id="">

	<option value="" selected>Select a Thana</option>

	<option value="Ahsanganj">Ahsanganj</option>

	<option value="Badalgachhi">Badalgachhi</option>

	<option value="Dhamuirhat">Dhamuirhat</option>

	<option value="Dhamurhat">Dhamurhat</option>

	<option value="Mahadebpur">Mahadebpur</option>

	<option value="Sadar">Naogaon Sadar</option>

	<option value="Niamatpur">Niamatpur</option>

	<option value="Nitpur">Nitpur</option>

	<option value="Patnitala">Patnitala</option>

	<option value="Prasadpur">Prasadpur</option>

	<option value="Raninagar">Raninagar</option>

	<option value="Sapahar">Sapahar</option>

</select>

<!--Natore-->

<select class="Natore" id="">

	<option value="" selected>Select a Thana</option>
	
	<option value="Gopalpur-UPO">Gopalpur UPO</option>

	<option value="Harua">Harua</option>

	<option value="Hatgurudaspur">Hatgurudaspur</option>

	<option value="Laxman">Laxman</option>

	<option value="Sadar">Natore Sadar</option>

	<option value="Singra">Singra</option>

</select>




















